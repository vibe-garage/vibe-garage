# Spark Swarm, Episode 8: Heads Up (Godot 4.8 beta 1)

From the Lexi Volt beginner series Spark Swarm, Episode 8, aired **Thu Nov 26, 2026**. [Watch on YouTube](https://www.youtube.com/watch?v=EUOHcm2_jbo) · [Full series playlist](https://www.youtube.com/playlist?list=PLSZThGGbiCo0)

Tutorial page with the episode's code and notes: https://vibegarage.neozonesproductions.com/spark-swarm/ep08.html

## What it builds

The end state of Episode 8, starting from Episode 7: the game gets a heads-up display — ten health pips, the wave number, and a crabs-left count that never lies, because the spawner announces the count instead of the screen guessing it.

- `hud.gd`: the HUD. Two Inspector NodePaths (spawner, spark), signal hookups in `_ready`, one starting-state ask, then it only listens. Pips are health drawn: the first health / 10 stay lit. The whole tree ignores the mouse.
- `wave_spawner.gd`: Episode 5's wave system, plus `crabs_remaining()` (owed + alive) and the `wave_progress` signal, emitted on wave start, spawn, and death (new in this episode).
- `spark.gd`: Episodes 1–7 movement, zap, health and death, unchanged.
- `game_over.gd` / `wave_banner.gd`: Episode 7's ending and Episode 5's banner, unchanged.
- `arena.tscn`: the arena with the HUD on the CanvasLayer.

## Godot version

Made and tested on **Godot 4.8 beta 1** (4.8.beta1.official.4d10419ca), Compatibility renderer, GDScript.

## How to run

1. Open Godot 4.8 beta 1.
2. In the Project Manager, click **Import** and pick `spark-swarm-ep08/project.godot`.
3. Press **Play** (F5).

## Controls

| Input | Action |
| --- | --- |
| WASD or arrow keys, gamepad left stick or D-pad | Move |
| Space, gamepad bottom face button | Zap |
| R | Restart after game over |

## Make it yours

Run wave 4: three crabs still owed, four on screen — the HUD says seven left (3 + 4), and wave 4 sends ten in all (4 + 3 x 2). If your count ever climbs, your screen is guessing.

## How this was made (AI use)

Lexi Volt's narration voice is AI-generated, and the scripts and the project code were written with AI tools.
Every project is then built, run and tested in the real Godot 4.8 beta 1 editor before release.

## Credits & licenses

- Code and scenes: Lexi Volt, MIT (see [LICENSE](LICENSE)).
- Sprite art (`art/crab.png`, `art/spark.png`): simple placeholder sprites made for this series, MIT like the code.

## Not included

The headless tests and the recording tools used to capture the video aren't included. No music is included. Export presets aren't included (they're per machine).
