# Spark Swarm, Episode 1: Your First Spark (Godot 4.8 beta 1)

From the Lexi Volt beginner series Spark Swarm, Episode 1, aired **Fri Nov 6, 2026**. [Watch on YouTube](https://www.youtube.com/watch?v=oFAzF93cemc) · [Full series playlist](https://www.youtube.com/playlist?list=PLSZThGGbiCo0)

Project folder: https://github.com/LexiVoltDev/godot-tutorials/tree/main/spark-swarm/ep01
This exact version is tagged `spark-swarm-ep01`: https://github.com/LexiVoltDev/godot-tutorials/tree/spark-swarm-ep01/spark-swarm/ep01

## What it builds

The end state of Episode 1: a spark you steer around a small floor and zap.

- Eased movement: the spark speeds up and slows down in about 0.1 s (`velocity.move_toward`), with keyboard or gamepad.
- A floor fence: the spark stays on the navy floor (Episode 2 removes this fence when real walls arrive).
- The zap: a jagged `Line2D` bolt and a zap sound, with a 0.2 s cooldown.
- A screen flash (at most 3 a second) and a small camera shake (6 px), so one tiny zap feels huge.

## Godot version

Made and tested on **Godot 4.8 beta 1** (4.8.beta1.official.4d10419ca), Compatibility renderer, GDScript.
The window is Godot's default 1152x648.

## How to run

1. Open Godot 4.8 beta 1.
2. In the Project Manager, click **Import** and pick `spark-swarm/ep01/project.godot`.
3. Press **Play** (F5).

## Controls

| Input | Action |
| --- | --- |
| WASD or arrow keys, gamepad left stick or D-pad | Move |
| Space, gamepad bottom face button | Zap |

## Files

- `spark.gd`: all of the episode's code (movement, fence, zap, flash, shake).
- `spark.tscn`: Spark (CharacterBody2D) with Sprite2D, CollisionShape2D (circle, radius 20), ZapLine (Line2D), ZapSound, and FlashLayer › Flash (ColorRect).
- `arena.tscn`: the main scene. Arena › Floor (ColorRect at 64, 64, size 1024 x 520), Spark, Camera2D.
- `project.godot`: Input Map (`move_left`, `move_right`, `move_up`, `move_down`, `zap`) and the Compatibility renderer.
- `art/spark_placeholder.svg`, `sfx/laserSmall_000.ogg`: the spark picture and the zap sound.

## Make it yours

Change one number and play again: `speed`, `accel` or `zap_length` in the Inspector, or the flash `0.25` and shake `6.0` in `spark.gd`.

## Run it in a browser

The video's last step exports to the web. Export presets aren't included (they're per machine).
In Godot: **Editor › Manage Export Templates** to install the templates, then **Project › Export › Add... › Web**,
and use **Remote Deploy › Run in Browser**.

## How this was made (AI use)

Lexi Volt's narration voice is AI-generated, and the scripts and the project code were written with AI tools.
The project was then built, run and tested in the real Godot 4.8 beta 1 editor before release, and it matches the code shown in the video.

## Credits & licenses

- Code and scenes: Lexi Volt, MIT (see [LICENSE](LICENSE)).
- Zap sound `sfx/laserSmall_000.ogg`: **Sci-Fi Sounds** by Kenney (www.kenney.nl), CC0 1.0. Original `License.txt` in `sfx/`.
- Spark picture `art/spark_placeholder.svg`: a simple two-circle shape made for this project, MIT like the code.

## Not included

The headless test and the recording tools used to capture the video aren't included. No music is included.
