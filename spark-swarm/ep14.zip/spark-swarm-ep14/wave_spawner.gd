extends Node2D
## WaveSpawner — Spark Swarm Episodes 10 + 12 + 13 (shipped merge).
## Ep12 ("The Boss") adds the boss wave on top of the Ep10 build:
## the spawner spawns the boss, the count excludes it, the clear
## check asks about it, and its death arrives on its own defeated
## signal — never on died. The Ep12 package spawner (scripts/code/
## wave_spawner_package.gd) carries the same boss logic without
## the level system; this file is that logic merged into the
## shipped Ep10/Ep11 spawner, verified by the Ep12 smoke test.
##
## Ep13 ("You Win") ports the Ep13 package's win condition onto
## this merged spawner (the package notes' build-stage rule: port
## the additions onto the then-current spawner, never the other
## way): a final_wave export, the run_won signal shouted from
## inside the clear check, the crabs_zapped / gems_collected
## counters kept at the died / collected events, total_crabs(),
## and the _won guard. One adaptation the merge forces: Ep12's
## boss calls minions through the door, and a minion's died would
## inflate the zapped tally past the run's 130 wave crabs — so
## minions run the drop roll through their own hookup and stay
## out of the tally, exactly as the boss itself does (Ep13's
## rule: the boss and its company are in no total).
##
## Ep5's wave spawner + Ep8's wave_progress + Ep9's loot and score,
## plus Ep10's growth: every collected gem also pays XP, XP fills
## the current level's price, and a filled price levels the spark
## up. The spawner owns the numbers and shouts the changes
## (xp_changed / level_up); the HUD label and the spark's heal
## listen. Levels live here, so a restart resets them with the
## score — Ep10's honest limit; saving is a later episode's job.
##
## Scene setup (unchanged from Ep5, plus the gem scene export):
##   WaveSpawner (Node2D, this script, in the "spawner" group)
##   ├── SpawnTimer (Timer, one_shot = true)  -> timeout -> _on_spawn_timer_timeout
##   └── BreakTimer (Timer, one_shot = true)  -> timeout -> _on_break_timer_timeout
## The crab scene, gem scene and arena are exported vars, set in
## the Inspector.

signal wave_started(wave_number: int, crab_count: int)
signal wave_cleared(wave_number: int)
## Ep8: the crabs-left count, announced on every change.
signal wave_progress(remaining: int)
## Ep9: shouted every time the score moves; the HUD listens.
signal score_changed(new_score: int)
## Ep10: shouted every time XP moves, with the current level's
## price, so the HUD label never has to ask twice.
signal xp_changed(xp: int, xp_needed_now: int, level: int)
## Ep10: shouted once per level gained, the moment it happens.
## The spark listens and patches itself up (spark.gd).
signal level_up(new_level: int)
## Ep12: the boss walked in — the HUD's boss bar shows, full.
signal boss_started(boss_max_health: int)
## Ep12: the boss's health moved — the bar redraws.
signal boss_health_changed(current: int, maximum: int)
## Ep12: the boss fell — the bar hides. A milestone, not a win.
signal boss_defeated
## Ep13: shouted exactly once, when the final wave is cleared.
## Carries the run's stats — only numbers this spawner actually
## counted: waves cleared, crabs zapped, gems collected, score.
signal run_won(stats: Dictionary)

## The crab scene, copied once per spawn (Episode 3/4).
@export var crab_scene: PackedScene
## The gem scene (Ep9), copied once per winning drop roll.
@export var gem_scene: PackedScene
## The boss scene (Ep12): an inherited crab scene with boss.gd.
@export var boss_scene: PackedScene
## The arena node new crabs (and dropped gems) are added to, so they
## live in the world, not inside the spawner. (NodePath export: node
## exports assigned in a .tscn need the NodePath form to resolve.)
@export var arena: NodePath

## Crabs in wave 1.
@export var first_wave_size: int = 4
## Extra crabs each new wave adds.
@export var wave_growth: int = 2
## Seconds between crabs inside one wave.
@export var spawn_gap: float = 0.9
## Seconds of quiet between waves.
@export var break_length: float = 4.0
## The odds that one kill drops a gem. 0.25 is one in four.
@export var drop_chance: float = 0.25
## Points one collected gem is worth (Ep9's score).
@export var gem_value: int = 10
## XP one collected gem pays (Ep10). Score is the bragging;
## XP is the growing. Same gem, two pockets.
@export var xp_per_gem: int = 1
## XP the first level costs.
@export var xp_base: int = 5
## Extra XP each new level adds to its price. Levels get
## hungrier by two, the way waves get bigger by two.
@export var xp_growth: int = 2
## The wave the boss walks in with (Ep12). Exactly one wave has
## a boss; waves after it are back to crabs only.
@export var boss_wave: int = 10
## The last wave of a run (Ep13). Clearing it wins the run.
## Season 1's run is ten waves — Ep12's boss walks in with this
## wave, so the run ends when the boss and its wave are down.
@export var final_wave: int = 10

var wave_number: int = 0
## The run's score (Ep9). Lives here, so a restart resets it.
var score: int = 0
## XP banked toward the current level's price (Ep10).
var xp: int = 0
## The spark's current level. Starts at 1.
var level: int = 1
## Run stats (Ep13), counted at the events themselves: zaps in
## _on_crab_died (Ep9's died only ever means a kill), gems in
## _on_gem_collected. Nothing polls, nothing guesses.
var crabs_zapped: int = 0
var gems_collected: int = 0
var _to_spawn: int = 0  # crabs still owed by the current wave
var _boss: Node2D = null  # Ep12: the boss, while it lives
var _boss_alive: bool = false  # Ep12: the boss stands
var _won: bool = false  # Ep13: the guard — run_won shouts once

@onready var _spawn_timer: Timer = $SpawnTimer
@onready var _break_timer: Timer = $BreakTimer


func _ready() -> void:
	# The first wave gets the same short break, so the player sees the
	# arena and the WAVE 1 banner before the first crab walks in.
	_break_timer.start(break_length)


## How many crabs a wave sends. Wave 1: 4, wave 2: 6, wave 3: 8.
func crabs_in_wave(wave: int) -> int:
	return first_wave_size + (wave - 1) * wave_growth


## Seconds one wave's spawning takes: the first crab is instant,
## every crab after it waits one gap. Wave 1: 3 x 0.9 = 2.7 s.
func spawn_span(wave: int) -> float:
	return (crabs_in_wave(wave) - 1) * spawn_gap


## Crabs the player still has to beat this wave — the ones on
## screen plus the ones this wave still owes (Episode 8).
func crabs_remaining() -> int:
	var count := _to_spawn + get_tree().get_nodes_in_group("enemies").size()
	if _boss_alive:
		count -= 1  # Ep12: the boss is not a crab left (see header)
	return count


## On-average gems for a clear of this many crabs: kills times the
## chance. Wave 3: 8 x 0.25 = 2. An average, not a promise.
func expected_gems(crab_count: int) -> float:
	return crab_count * drop_chance


## Total crabs in a whole run of the given length (Ep13): the
## wave sizes added up. Ten waves: 4+6+8+10+12+14+16+18+20+22
## = 130. The boss is not in this total, and neither are its
## minions — the tally counts the waves' crabs, nothing else.
func total_crabs(waves: int) -> int:
	var total := 0
	for wave in range(1, waves + 1):
		total += crabs_in_wave(wave)
	return total


## The price of a level: a base, plus a growth — the wave formula
## wearing a new hat. Level 1 costs 5, level 2 costs 7, level 3
## costs 9.
func xp_needed(for_level: int) -> int:
	return xp_base + (for_level - 1) * xp_growth


## On-average XP for a clear of this many crabs: one XP rides
## every expected gem. Wave 3: 2 gems, 2 XP.
func expected_xp(crab_count: int) -> float:
	return expected_gems(crab_count) * xp_per_gem


func _on_break_timer_timeout() -> void:
	_start_wave()


func _start_wave() -> void:
	wave_number += 1
	_to_spawn = crabs_in_wave(wave_number)
	wave_started.emit(wave_number, _to_spawn)
	# On the boss wave, the big one walks in first (Ep12). It is
	# spawned by the spawner, like everything else that fights.
	if wave_number == boss_wave and boss_scene != null:
		_spawn_boss()
	wave_progress.emit(crabs_remaining())
	_spawn_crab()  # the first crab of the wave arrives right away
	if _to_spawn > 0:
		_spawn_timer.start(spawn_gap)


func _on_spawn_timer_timeout() -> void:
	_spawn_crab()
	if _to_spawn > 0:
		_spawn_timer.start(spawn_gap)


func _spawn_crab() -> void:
	_add_crab(_spawn_point())
	_to_spawn -= 1
	# Owed became alive: the total does not move, but it is still
	# announced, so listeners never have to wonder. (Episode 8.)
	wave_progress.emit(crabs_remaining())


## THE DOOR (Ep12). Every regular crab in the game comes through
## here — wave crabs and boss minions alike — so every crab gets
## the same two connections: tree_exited for the count and the
## clear check, died for the loot roll. A crab that enters any
## other way is a crab whose death nobody hears (the Ep12 bug).
## Ep13 adds one distinction at the door: a wave crab's died also
## feeds the run's zapped tally, while a minion's died runs the
## loot roll only — minions are the boss's company, and the tally
## counts the waves' 130 crabs, nothing else.
func _add_crab(at_position: Vector2, counted := true) -> Node2D:
	var crab = crab_scene.instantiate()
	crab.position = at_position
	get_node(arena).add_child(crab)
	# tree_exited fires when the crab leaves the tree (any reason),
	# which is the spawner's cue to check whether the wave is over.
	crab.tree_exited.connect(_on_crab_gone)
	# died fires only for a zap kill, and carries the spot where
	# the crab fell — that's the drop roll's one hookup. (The crab
	# is deliberately untyped here: died is the crab script's own
	# signal, not a Node2D one.)
	if counted:
		crab.died.connect(_on_crab_died)
	else:
		crab.died.connect(_on_minion_died)
	return crab


## The boss enters through a door of its own (Ep12): the spawner
## spawns it, wires its shouts, and remembers it — so the count
## can exclude it and the clear check can ask about it.
func _spawn_boss() -> void:
	_boss = boss_scene.instantiate()
	_boss.position = _spawn_point()
	get_node(arena).add_child(_boss)
	# Untyped on purpose: defeated, health_changed and
	# minion_requested are the boss script's own signals.
	_boss.tree_exited.connect(_on_boss_gone)
	_boss.defeated.connect(_on_boss_died)
	_boss.health_changed.connect(_on_boss_health_changed)
	_boss.minion_requested.connect(_on_boss_minion_requested)
	_boss_alive = true
	boss_started.emit(_boss.max_health)


func _on_crab_gone() -> void:
	# During a scene reload (Ep7), a crab can leave the tree after
	# the spawner itself has already left it — get_tree() is null
	# then, and there is no wave left to check. Bail out quietly.
	if not is_inside_tree():
		return
	wave_progress.emit(crabs_remaining())
	_check_wave_clear()


func _on_boss_gone() -> void:
	if not is_inside_tree():
		return  # scene teardown, same guard as _on_crab_gone
	_boss = null
	_boss_alive = false
	wave_progress.emit(crabs_remaining())
	_check_wave_clear()


## A wave is cleared when nothing is left to spawn, no regular
## crabs remain, AND the boss is down (Ep12). Before Ep12 the
## boss clause did not exist because the group check did the
## asking; now the count excludes the boss, so the check names it.
func _check_wave_clear() -> void:
	if _to_spawn == 0 and not _boss_alive and crabs_remaining() == 0:
		wave_cleared.emit(wave_number)
		if wave_number >= final_wave:
			# THE WIN (Ep13). It lives here — inside the cleared
			# event — and not in any process loop, so breaks and
			# the opening frame can never fake it. The guard
			# keeps it to exactly once.
			if not _won:
				_won = true
				run_won.emit({
					"waves_cleared": wave_number,
					"crabs_zapped": crabs_zapped,
					"gems_collected": gems_collected,
					"score": score,
				})
		else:
			_break_timer.start(break_length)


## The boss fell (Ep12). Announced for the HUD (the bar hides).
## The shout that lands here is the boss's OWN defeated, never
## the crabs' died: the died hookup is the regular crabs' kill
## tally (Ep9's roll; Ep13's zapped count), and the boss is in
## none of those numbers.
func _on_boss_died(_at_position: Vector2) -> void:
	boss_defeated.emit()


## The boss's health shout, passed along to the HUD's boss bar.
func _on_boss_health_changed(current: int, maximum: int) -> void:
	boss_health_changed.emit(current, maximum)


## The boss asked for company (Ep12): spawn a regular crab AT
## the boss, through the door, so the minion is a full citizen —
## counted, loot-rolled, and heard when it leaves. Minions are
## not owed by the wave, so _to_spawn does not move.
func _on_boss_minion_requested() -> void:
	if _boss == null:
		return
	var spot := _boss.global_position + Vector2(
			randf_range(-24.0, 24.0), randf_range(-24.0, 24.0))
	_add_crab(spot, false)  # Ep13: company, not tally (see _add_crab)
	wave_progress.emit(crabs_remaining())


## THE DROP ROLL (Ep9). Runs exactly once per kill, because died
## does. Random rewards roll at the event, never in a loop.
## Ep13: a wave crab's death also feeds the run's zapped tally —
## counted here, at the event, never polled.
func _on_crab_died(at_position: Vector2) -> void:
	crabs_zapped += 1
	if randf() < drop_chance:
		_drop_gem(at_position)


## A minion's death (Ep13): the same drop roll, but the tally
## does not move — minions are the boss's company, and the run's
## 130 counts the waves' crabs only (see _add_crab).
func _on_minion_died(at_position: Vector2) -> void:
	if randf() < drop_chance:
		_drop_gem(at_position)


func _drop_gem(at_position: Vector2) -> void:
	var gem = gem_scene.instantiate()
	gem.position = at_position
	get_node(arena).add_child(gem)
	gem.collected.connect(_on_gem_collected)


## A gem was GRABBED — the one moment money and growth are counted.
## Ep10's first version counted XP on the gem's tree_exited instead:
## floor gems "paid" their XP when a restart swept them out of the
## scene, and the spark leveled up by dying. Count the grab, not
## the goodbye.
func _on_gem_collected(_gem: Area2D) -> void:
	gems_collected += 1  # Ep13: the victory screen's third number
	score += gem_value
	score_changed.emit(score)
	_gain_xp(xp_per_gem)


## Bank XP, then pay level prices while the bank covers them.
## Leftover XP carries into the next level — no step is wasted.
func _gain_xp(amount: int) -> void:
	if amount <= 0:
		return
	xp += amount
	while xp >= xp_needed(level):
		xp -= xp_needed(level)
		level += 1
		level_up.emit(level)
	xp_changed.emit(xp, xp_needed(level), level)


## A point just outside a random edge of the arena (Episode 4's rule:
## crabs walk in from off screen, from any edge).
func _spawn_point() -> Vector2:
	var rect := Rect2(Vector2(64, 64), Vector2(1024, 520))
	var margin := 48.0
	var edge := randi() % 4
	match edge:
		0:  # top
			return Vector2(randf_range(rect.position.x, rect.end.x), rect.position.y - margin)
		1:  # bottom
			return Vector2(randf_range(rect.position.x, rect.end.x), rect.position.y + margin)
		2:  # left
			return Vector2(rect.position.x - margin, randf_range(rect.position.y, rect.end.y))
		_:  # right
			return Vector2(rect.end.x + margin, randf_range(rect.position.y, rect.end.y))
