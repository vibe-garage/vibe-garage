extends CanvasLayer
## Victory — Spark Swarm Episode 13 ("You Win").
##
## The mirror of Ep7's GameOver screen, built the same way on
## purpose: a CanvasLayer that hears one signal, fills in the
## numbers, shows its panel and pauses the tree. Where GameOver
## hears the spark's died, Victory hears the spawner's run_won
## (Ep13) — and the stats it shows are the counters the spawner
## kept along the way, so every number on this screen is a number
## the game truly tracked.
##
## Scene setup (built in the episode, mirroring GameOver):
##   Victory (CanvasLayer, this script)
##     Process Mode: Always (set in the Inspector — the same Ep7
##     rule: without it, the paused tree stops this node too and
##     the restart key goes deaf)
##   └── Panel (Control, full rect, starts hidden)
##       ├── Dim (ColorRect, full rect, black, alpha 0.55)
##       ├── Title (Label, "YOU WIN")
##       ├── Waves (Label, "Waves cleared  10")
##       ├── Zapped (Label, "Crabs zapped  130")
##       ├── Gems (Label, "Gems collected  27")
##       ├── Score (Label, "Score  270")
##       └── Hint (Label, "Press R to run it back")
##
## Project setup: the input action "restart" on the R key,
## added in Episode 7.
##
## THE EP13 BUG (first version, kept here as the warning): this
## screen first checked the win by POLLING in _process —
##     if spawner.crabs_remaining() == 0: show_victory()
## crabs_remaining() reads 0 before wave 1 spawns and during every
## break, so the game declared victory on its opening frame. The
## fix is Ep9's rule wearing a new hat: moments are events, never
## polls. The win now arrives as the run_won signal, shouted from
## inside the wave_cleared check — the one moment "the final wave
## is cleared" is actually true.

@onready var _panel: Control = $Panel
@onready var _waves: Label = $Panel/Waves
@onready var _zapped: Label = $Panel/Zapped
@onready var _gems: Label = $Panel/Gems
@onready var _score: Label = $Panel/Score

var _shown: bool = false


func _ready() -> void:
	_panel.hide()
	# The spawner is found by its group — the lookup the Ep5
	# banner and Ep7's GameOver already use for their nodes.
	var spawner := get_tree().get_first_node_in_group("spawner")
	if spawner != null:
		spawner.run_won.connect(_on_run_won)


func _on_run_won(stats: Dictionary) -> void:
	if _shown:
		return
	# THE TIE RULE: if the spark is already dead when the last
	# crab falls, the run is a loss, not a win — you have to be
	# standing to win it. A crab's parting touch sets health to 0
	# inside the physics step, before the exit is processed here,
	# so this read is settled by the time run_won arrives. Ep7's
	# GameOver shows instead.
	var spark := get_tree().get_first_node_in_group("player")
	if spark != null and int(spark.get("health")) <= 0:
		return
	_shown = true
	_waves.text = "Waves cleared  %d" % int(stats["waves_cleared"])
	_zapped.text = "Crabs zapped  %d" % int(stats["crabs_zapped"])
	_gems.text = "Gems collected  %d" % int(stats["gems_collected"])
	_score.text = "Score  %d" % int(stats["score"])
	_panel.show()
	get_tree().paused = true


func _unhandled_input(event: InputEvent) -> void:
	if _shown and event.is_action_pressed("restart"):
		# Unpause FIRST (Ep7's rule): SceneTree.paused survives a
		# scene change, so reloading while paused starts frozen.
		get_tree().paused = false
		get_tree().reload_current_scene()
