extends Label
## Spark Swarm Ep14: the version label.
##
## Reads the game's version from Project Settings
## (Project > Project Settings > Application > Config > Version)
## and shows it as "v1.0". Project Settings are packed into every
## export, so this label reads the same in the editor and in the
## exported game.
##
## The first version of this label read a loose "version.txt" file
## from res:// instead. That works in the editor, which can see
## every file in the project folder — but an export only packs
## the files Godot knows are part of the game, so in the exported
## build the file was missing and the label came up empty.
## Settings travel; stray files don't.


func _ready() -> void:
	text = version_text()


static func version_text() -> String:
	var version: String = ProjectSettings.get_setting(
		"application/config/version", "1.0")
	return "v" + version
