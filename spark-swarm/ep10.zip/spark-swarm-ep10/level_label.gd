extends Label
## LevelLabel — Spark Swarm Episode 10 ("Level Up").
##
## One new label in the Ep8 HUD's top-left stack, under the score:
## it shows the spark's level and the XP banked toward the next
## one ("LV 1 · XP 3/5"). Ep9's ScoreLabel with new ears — the
## spawner owns the numbers and shouts xp_changed; this label's
## whole job is: hear the shout, write the truth. On level_up it
## pops, so the moment catches the player's eye.
##
## Scene setup: a Label in the HUD's CanvasLayer with this script.
## The spawner is found through the "spawner" group — the same
## lookup Ep5's WaveBanner and Ep9's ScoreLabel use.

func _ready() -> void:
	var spawner := get_tree().get_first_node_in_group("spawner")
	if spawner != null:
		spawner.xp_changed.connect(_on_xp_changed)
		spawner.level_up.connect(_on_level_up)
		# Signals only announce changes, and nothing has changed
		# yet: ask for the starting state, once (the Ep8 HUD rule).
		_on_xp_changed(spawner.xp, spawner.xp_needed(spawner.level), spawner.level)


func _on_xp_changed(xp_now: int, xp_price: int, level_now: int) -> void:
	text = "LV %d · XP %d/%d" % [level_now, xp_now, xp_price]


func _on_level_up(_new_level: int) -> void:
	# A quick scale bounce around the label's centre, then settle.
	pivot_offset = size * 0.5
	scale = Vector2(1.35, 1.35)
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2.ONE, 0.25)
