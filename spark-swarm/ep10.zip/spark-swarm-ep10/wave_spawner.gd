extends Node2D
## WaveSpawner — Spark Swarm Episode 10 ("Level Up").
##
## Ep5's wave spawner + Ep8's wave_progress + Ep9's loot and score,
## plus Ep10's growth: every collected gem also pays XP, XP fills
## the current level's price, and a filled price levels the spark
## up. The spawner owns the numbers and shouts the changes
## (xp_changed / level_up); the HUD label and the spark's heal
## listen. Levels live here, so a restart resets them with the
## score — Ep10's honest limit; saving is a later episode's job.
##
## Scene setup (unchanged from Ep5, plus the gem scene export):
##   WaveSpawner (Node2D, this script, in the "spawner" group)
##   ├── SpawnTimer (Timer, one_shot = true)  -> timeout -> _on_spawn_timer_timeout
##   └── BreakTimer (Timer, one_shot = true)  -> timeout -> _on_break_timer_timeout
## The crab scene, gem scene and arena are exported vars, set in
## the Inspector.

signal wave_started(wave_number: int, crab_count: int)
signal wave_cleared(wave_number: int)
## Ep8: the crabs-left count, announced on every change.
signal wave_progress(remaining: int)
## Ep9: shouted every time the score moves; the HUD listens.
signal score_changed(new_score: int)
## Ep10: shouted every time XP moves, with the current level's
## price, so the HUD label never has to ask twice.
signal xp_changed(xp: int, xp_needed_now: int, level: int)
## Ep10: shouted once per level gained, the moment it happens.
## The spark listens and patches itself up (spark.gd).
signal level_up(new_level: int)

## The crab scene, copied once per spawn (Episode 3/4).
@export var crab_scene: PackedScene
## The gem scene (Ep9), copied once per winning drop roll.
@export var gem_scene: PackedScene
## The arena node new crabs (and dropped gems) are added to, so they
## live in the world, not inside the spawner. (NodePath export: node
## exports assigned in a .tscn need the NodePath form to resolve.)
@export var arena: NodePath

## Crabs in wave 1.
@export var first_wave_size: int = 4
## Extra crabs each new wave adds.
@export var wave_growth: int = 2
## Seconds between crabs inside one wave.
@export var spawn_gap: float = 0.9
## Seconds of quiet between waves.
@export var break_length: float = 4.0
## The odds that one kill drops a gem. 0.25 is one in four.
@export var drop_chance: float = 0.25
## Points one collected gem is worth (Ep9's score).
@export var gem_value: int = 10
## XP one collected gem pays (Ep10). Score is the bragging;
## XP is the growing. Same gem, two pockets.
@export var xp_per_gem: int = 1
## XP the first level costs.
@export var xp_base: int = 5
## Extra XP each new level adds to its price. Levels get
## hungrier by two, the way waves get bigger by two.
@export var xp_growth: int = 2

var wave_number: int = 0
## The run's score (Ep9). Lives here, so a restart resets it.
var score: int = 0
## XP banked toward the current level's price (Ep10).
var xp: int = 0
## The spark's current level. Starts at 1.
var level: int = 1
var _to_spawn: int = 0  # crabs still owed by the current wave

@onready var _spawn_timer: Timer = $SpawnTimer
@onready var _break_timer: Timer = $BreakTimer


func _ready() -> void:
	# The first wave gets the same short break, so the player sees the
	# arena and the WAVE 1 banner before the first crab walks in.
	_break_timer.start(break_length)


## How many crabs a wave sends. Wave 1: 4, wave 2: 6, wave 3: 8.
func crabs_in_wave(wave: int) -> int:
	return first_wave_size + (wave - 1) * wave_growth


## Seconds one wave's spawning takes: the first crab is instant,
## every crab after it waits one gap. Wave 1: 3 x 0.9 = 2.7 s.
func spawn_span(wave: int) -> float:
	return (crabs_in_wave(wave) - 1) * spawn_gap


## Crabs the player still has to beat this wave — the ones on
## screen plus the ones this wave still owes (Episode 8).
func crabs_remaining() -> int:
	return _to_spawn + get_tree().get_nodes_in_group("enemies").size()


## On-average gems for a clear of this many crabs: kills times the
## chance. Wave 3: 8 x 0.25 = 2. An average, not a promise.
func expected_gems(crab_count: int) -> float:
	return crab_count * drop_chance


## The price of a level: a base, plus a growth — the wave formula
## wearing a new hat. Level 1 costs 5, level 2 costs 7, level 3
## costs 9.
func xp_needed(for_level: int) -> int:
	return xp_base + (for_level - 1) * xp_growth


## On-average XP for a clear of this many crabs: one XP rides
## every expected gem. Wave 3: 2 gems, 2 XP.
func expected_xp(crab_count: int) -> float:
	return expected_gems(crab_count) * xp_per_gem


func _on_break_timer_timeout() -> void:
	_start_wave()


func _start_wave() -> void:
	wave_number += 1
	_to_spawn = crabs_in_wave(wave_number)
	wave_started.emit(wave_number, _to_spawn)
	wave_progress.emit(crabs_remaining())
	_spawn_crab()  # the first crab of the wave arrives right away
	if _to_spawn > 0:
		_spawn_timer.start(spawn_gap)


func _on_spawn_timer_timeout() -> void:
	_spawn_crab()
	if _to_spawn > 0:
		_spawn_timer.start(spawn_gap)


func _spawn_crab() -> void:
	var crab = crab_scene.instantiate()
	crab.position = _spawn_point()
	get_node(arena).add_child(crab)
	# tree_exited fires when the crab leaves the tree (any reason),
	# which is the spawner's cue to check whether the wave is over.
	crab.tree_exited.connect(_on_crab_gone)
	# died fires only for a zap kill, and carries the spot where the
	# crab fell — that's the drop roll's one hookup. (The crab is
	# deliberately untyped here: died is the crab script's own
	# signal, not a Node2D one.)
	crab.died.connect(_on_crab_died)
	_to_spawn -= 1
	wave_progress.emit(crabs_remaining())


func _on_crab_gone() -> void:
	# During a scene reload (Ep7), a crab can leave the tree after
	# the spawner itself has already left it — get_tree() is null
	# then, and there is no wave left to check. Bail out quietly.
	if not is_inside_tree():
		return
	wave_progress.emit(crabs_remaining())
	# A wave is cleared when nothing is left to spawn AND no crab
	# from the group is still alive in the arena.
	if _to_spawn == 0 and get_tree().get_nodes_in_group("enemies").is_empty():
		wave_cleared.emit(wave_number)
		_break_timer.start(break_length)


## THE DROP ROLL (Ep9). Runs exactly once per kill, because died
## does. Random rewards roll at the event, never in a loop.
func _on_crab_died(at_position: Vector2) -> void:
	if randf() < drop_chance:
		_drop_gem(at_position)


func _drop_gem(at_position: Vector2) -> void:
	var gem = gem_scene.instantiate()
	gem.position = at_position
	get_node(arena).add_child(gem)
	gem.collected.connect(_on_gem_collected)


## A gem was GRABBED — the one moment money and growth are counted.
## Ep10's first version counted XP on the gem's tree_exited instead:
## floor gems "paid" their XP when a restart swept them out of the
## scene, and the spark leveled up by dying. Count the grab, not
## the goodbye.
func _on_gem_collected(_gem: Area2D) -> void:
	score += gem_value
	score_changed.emit(score)
	_gain_xp(xp_per_gem)


## Bank XP, then pay level prices while the bank covers them.
## Leftover XP carries into the next level — no step is wasted.
func _gain_xp(amount: int) -> void:
	if amount <= 0:
		return
	xp += amount
	while xp >= xp_needed(level):
		xp -= xp_needed(level)
		level += 1
		level_up.emit(level)
	xp_changed.emit(xp, xp_needed(level), level)


## A point just outside a random edge of the arena (Episode 4's rule:
## crabs walk in from off screen, from any edge).
func _spawn_point() -> Vector2:
	var rect := Rect2(Vector2(64, 64), Vector2(1024, 520))
	var margin := 48.0
	var edge := randi() % 4
	match edge:
		0:  # top
			return Vector2(randf_range(rect.position.x, rect.end.x), rect.position.y - margin)
		1:  # bottom
			return Vector2(randf_range(rect.position.x, rect.end.x), rect.position.y + margin)
		2:  # left
			return Vector2(rect.position.x - margin, randf_range(rect.position.y, rect.end.y))
		_:  # right
			return Vector2(rect.end.x + margin, randf_range(rect.position.y, rect.end.y))
