extends Label
## ScoreLabel — Spark Swarm Episode 9 ("Loot Drop").
##
## One new label in the Ep8 HUD, next to health, wave and crabs
## left. The spawner owns the score and shouts score_changed (Ep5's
## signal pattern, same as the banner); this label's whole job is:
## hear the shout, write the number.
##
## Scene setup: a Label in the HUD's CanvasLayer with this script.
## The spawner is found through the "spawner" group — the same
## lookup the Ep5 WaveBanner uses.

func _ready() -> void:
	var spawner := get_tree().get_first_node_in_group("spawner")
	if spawner != null:
		spawner.score_changed.connect(_on_score_changed)
	_on_score_changed(0)


func _on_score_changed(new_score: int) -> void:
	text = "SCORE %d" % new_score
