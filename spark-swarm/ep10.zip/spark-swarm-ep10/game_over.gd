extends CanvasLayer
## GameOver — Spark Swarm Episode 7 ("Game Over").
##
## Listens for the spark's died signal: fills in the wave the player
## reached, shows the panel, and pauses the tree so the run freezes
## behind the dim. The restart key reloads the scene instead of
## resetting by hand — the scene file is the reset list, so the next
## run starts exactly as saved: health full, wave zero, arena empty.
##
## Scene setup (built in the episode):
##   GameOver (CanvasLayer, this script)
##     Process Mode: Always (set in the Inspector — without it, the
##     paused tree stops this node too, and the restart key goes deaf)
##   └── Panel (Control, full rect, starts hidden)
##       ├── Dim (ColorRect, full rect, black, alpha 0.55)
##       ├── Title (Label, "GAME OVER")
##       ├── Sub (Label, "You reached wave N" — the N is set in code)
##       └── Hint (Label, "Press R to run it back")
##
## Project setup: an input action named "restart" on the R key,
## added in Project Settings > Input Map (Episode 1's rule:
## name your controls, then ask for the name in code).

@onready var _panel: Control = $Panel
@onready var _sub: Label = $Panel/Sub

var _over: bool = false


func _ready() -> void:
	_panel.hide()
	# The banner found the spawner by its group in Episode 5;
	# the spark is in the "player" group (Episode 3's targeting).
	var spark := get_tree().get_first_node_in_group("player")
	if spark != null:
		spark.died.connect(_on_game_over)


func _on_game_over() -> void:
	if _over:
		return
	_over = true
	var wave := 0
	var spawner := get_tree().get_first_node_in_group("spawner")
	if spawner != null:
		wave = int(spawner.get("wave_number"))
	_sub.text = "You reached wave %d" % wave
	_panel.show()
	get_tree().paused = true


func _unhandled_input(event: InputEvent) -> void:
	if _over and event.is_action_pressed("restart"):
		# Unpause FIRST: SceneTree.paused survives a scene change,
		# so reloading while paused starts the new run frozen.
		get_tree().paused = false
		get_tree().reload_current_scene()
