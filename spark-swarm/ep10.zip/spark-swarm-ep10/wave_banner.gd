extends Label
## WaveBanner — the Ep5 banner. Listens for the spawner's signals:
## WAVE N when a wave starts, CLEARED when one falls, each fading
## out over two seconds (Ep1's tween).

var _fade: Tween


func _ready() -> void:
	modulate.a = 0.0
	var spawner := get_tree().get_first_node_in_group("spawner")
	if spawner != null:
		spawner.wave_started.connect(_on_wave_started)
		spawner.wave_cleared.connect(_on_wave_cleared)


func _on_wave_started(wave_number: int, _crab_count: int) -> void:
	_show("WAVE %d" % wave_number)


func _on_wave_cleared(_wave_number: int) -> void:
	_show("CLEARED")


func _show(what: String) -> void:
	text = what
	if _fade != null and _fade.is_valid():
		_fade.kill()
	modulate.a = 1.0
	_fade = create_tween()
	_fade.tween_interval(0.6)
	_fade.tween_property(self, "modulate:a", 0.0, 2.0)
