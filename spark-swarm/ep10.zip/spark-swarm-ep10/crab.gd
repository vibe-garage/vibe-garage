extends CharacterBody2D
## Crab — the enemy (Episodes 3 + 6 + 9, series build).
## Walks at the spark and dies to one zap (Ep3). Lives in the
## "enemies" group (set in the scene, the Groups-dock way, so it
## persists).
##
## Ep6: the crab fights back. After sliding, it asks what it ran
## into; touching the spark calls the spark's take_damage. A landed
## hit knocks the crab back, so it has to walk in again — and the
## spark's own hit cooldown decides whether a touch counts at all.
##
## Ep9: the crab gains a died signal, shouted exactly once at the
## moment a zap kills it, carrying the spot where it fell. Unlike
## tree_exited — which fires for ANY exit (despawn, restart, death;
## Episode 5's lesson) — died only ever means a kill, so Ep9's drop
## roll hangs off it and a vanish can never pay out.

## Fires exactly once, at the moment a zap kills this crab, with the
## spot where it died.
signal died(at_position: Vector2)

@export var speed: float = 95.0
## Health the spark loses per landed touch. Ten hits empty a
## 100-health bar.
@export var damage: int = 10
## How hard a landed hit shoves the crab back, in pixels per second.
## The shove fades in about a fifth of a second.
@export var knockback_speed: float = 260.0

var _target: Node2D
var _knockback: Vector2 = Vector2.ZERO


func _ready() -> void:
	_target = get_tree().get_first_node_in_group("player") as Node2D


func _physics_process(delta: float) -> void:
	if _target == null:
		return
	var dir := (_target.global_position - global_position).normalized()
	_knockback = _knockback.move_toward(Vector2.ZERO, 1400.0 * delta)
	velocity = dir * speed + _knockback
	move_and_slide()
	_touch_player()


## Did we just run into the spark? Slide collisions report every
## physics frame while two bodies touch — they are a report, not an
## event — so this asks every frame and lets the spark's hit
## cooldown sort out which touches are real hits.
func _touch_player() -> void:
	for i in get_slide_collision_count():
		var body := get_slide_collision(i).get_collider() as Node2D
		if body != null and body.is_in_group("player") \
				and body.has_method("take_damage"):
			if body.take_damage(damage):
				# The hit landed: bounce off, straight away from
				# the spark, and walk back in.
				var away := (global_position - body.global_position).normalized()
				_knockback = away * knockback_speed


func take_hit() -> void:
	# One zap is enough (Ep3). Shout died first, with the position,
	# THEN leave the tree — after queue_free there is no position
	# left to send. Leaving the tree also fires tree_exited, which
	# is how the Ep5 spawner knows a crab is gone.
	died.emit(global_position)
	queue_free()
