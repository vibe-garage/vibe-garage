# Spark Swarm — Episode 10: Level Up

The complete Godot 4.8 beta 1 project at the end of Episode 10 of
Spark Swarm: gems pay XP (1 per grab) toward a rising price list
(5, 7, 9), a level-up heals the spark for 20, and the HUD shows the
level and XP progress.

Open the folder in Godot 4.8 beta 1 and press Play. WASD or arrow
keys move the spark (it also plays itself if you don't touch
anything).

Watch the episode: https://www.youtube.com/watch?v=VIDEO_ID_PENDING
Tutorial page: https://vibegarage.neozonesproductions.com/spark-swarm/ep10.html

Art and sounds by Kenney (CC0) — see CREDITS.md.
