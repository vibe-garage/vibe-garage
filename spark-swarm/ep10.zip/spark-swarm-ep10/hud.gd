extends Control
## HUD — Spark Swarm Episode 8 ("Heads Up").
##
## The always-on layer: pips for the player's health, the current
## wave, and how many crabs are left. The HUD owns no numbers. Every
## value it shows arrives on a signal, or is asked for exactly once
## in _ready — after that, it only listens.
##
## Health is Episode 6's model: 100 health, 10 lost per touch, so
## the spark takes ten hits. The pips are that number drawn: ten
## squares, one per hit, and a hit darkens exactly one pip
## (health / 10 stay lit).
##
## Scene setup (built in the episode, on Episode 5's CanvasLayer):
##   CanvasLayer
##   ├── WaveBanner (Label — Episode 5's banner; it announces)
##   └── HUD (Control, this script; anchors preset: Full Rect)
##       ├── TopLeft (VBoxContainer, anchored top-left, small margin)
##       │   ├── WaveLabel (Label, placeholder text "WAVE 1")
##       │   └── CrabsLabel (Label, placeholder text "CRABS LEFT: 0")
##       └── Hearts (HBoxContainer, anchored top-right,
##           │       Grow Horizontal: Begin)
##           ├── Pip1 (ColorRect, 28x28, warm red)
##           ├── Pip2 (ColorRect)
##           └── … Pip10 (ColorRect)
##
## The episode's bug (first version, kept here as a warning): the
## crabs label was refreshed in _process by counting the "enemies"
## group. That count can only see crabs that already exist — never
## the ones the wave still owes — so at the start of wave 2 the HUD
## read CRABS LEFT: 1 while five more crabs were on their way in,
## and the number climbed while the player was winning. The fix is
## the spawner's wave_progress signal: owed + alive, announced by
## the one node that knows both. See wave_spawner.gd (Episode 8).

## Where the wave spawner lives in the scene (Inspector-assigned).
## A NodePath, like Episode 5's arena setting: paths assigned in
## the scene resolve; a typed node export does not.
@export var spawner_path: NodePath
## Where the player (the spark) lives in the scene.
@export var player_path: NodePath

@onready var _wave_label: Label = $TopLeft/WaveLabel
@onready var _crabs_label: Label = $TopLeft/CrabsLabel
@onready var _hearts: HBoxContainer = $Hearts

var _spawner
var _player


func _ready() -> void:
	_ignore_mouse(self)
	if spawner_path.is_empty() or player_path.is_empty():
		push_warning("HUD: spawner_path and player_path must be set in the Inspector.")
		return
	_spawner = get_node(spawner_path)
	_player = get_node(player_path)
	# Subscribe to the shouts (signals from Episodes 5, 6 and 8).
	_spawner.wave_started.connect(_on_wave_started)
	_spawner.wave_cleared.connect(_on_wave_cleared)
	_spawner.wave_progress.connect(_on_wave_progress)
	_player.health_changed.connect(_on_health_changed)
	# Signals only announce changes, and nothing has changed yet:
	# ask both systems for the starting state, once. After this,
	# the HUD never asks again — it listens.
	_on_health_changed(_player.health)
	_on_wave_progress(_spawner.crabs_remaining())


## A HUD that eats clicks is a bug with good graphics: every
## Control in this tree ignores the mouse, so input passes
## straight through to the game.
func _ignore_mouse(control: Control) -> void:
	control.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for child in control.get_children():
		if child is Control:
			_ignore_mouse(child)


func _on_wave_started(wave_number: int, _crab_count: int) -> void:
	_wave_label.text = "WAVE %d" % wave_number


func _on_wave_cleared(_wave_number: int) -> void:
	_crabs_label.text = "CRABS LEFT: 0"


func _on_wave_progress(remaining: int) -> void:
	_crabs_label.text = "CRABS LEFT: %d" % remaining


## Pips are the health number, drawn: health is counted in tens
## (Episode 6: 100 health, 10 per hit), so the first health / 10
## pips stay lit and the rest go dark.
func _on_health_changed(new_health: int) -> void:
	var lit := new_health / 10
	var pips := _hearts.get_children()
	for i in pips.size():
		(pips[i] as ColorRect).modulate.a = 1.0 if i < lit else 0.25
