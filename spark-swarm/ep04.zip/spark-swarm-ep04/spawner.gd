extends Node2D

@export var enemy_scene: PackedScene
@export var margin := 64.0

const FLOOR := Rect2(96, 96, 2112, 1088)


func _on_spawn_timer_timeout() -> void:
	var crab := enemy_scene.instantiate()
	crab.position = spawn_point()
	crab.target = get_tree().get_first_node_in_group("player")
	add_child(crab)


func spawn_point() -> Vector2:
	var center := get_viewport().get_camera_2d().get_screen_center_position()
	var radius := get_viewport_rect().size.length() / 2.0 + margin
	var point := Vector2.ZERO
	while not FLOOR.has_point(point):
		point = center + Vector2.RIGHT.rotated(randf_range(0.0, TAU)) * radius
	return point
