# Spark Swarm, Episode 4: Endless Swarm (Godot 4.8 beta 1)

From the Lexi Volt beginner series Spark Swarm, Episode 4, airing **Fri Nov 20, 2026**. Video coming soon · [Full series playlist](https://www.youtube.com/playlist?list=PLSZThGGbiCo0)

## What it builds

The end state of Episode 4, starting from Episode 3: a Timer and a copied crab scene keep crabs walking in from off screen, once a second, forever.

- `arena.tscn` gains `Spawner` (`Node2D` at 0, 0, script `spawner.gd`, Enemy Scene = `enemy.tscn`) › `SpawnTimer` (`Timer`, Wait Time 1 s, One Shot off, Autostart on). SpawnTimer `timeout` is connected to `Spawner._on_spawn_timer_timeout`.
- `spawner.gd`: each timeout instantiates `enemy_scene`, places the crab at `spawn_point()`, sets its `target` to the first node in group `player`, and adds it with `add_child`.
- `spawn_point()`: a random point on a circle around the camera's screen center, half the viewport diagonal plus `margin` (64 px) away, picked again until it lies inside `FLOOR` = `Rect2(96, 96, 2112, 1088)`.
- Everything else is unchanged from Episode 3.

## Godot version

Made and tested on **Godot 4.8 beta 1** (4.8.beta1.official.4d10419ca), Compatibility renderer, GDScript.
The Remote tab and the Signals dock in 4.8 can still change between betas.

## How to run

1. Open Godot 4.8 beta 1.
2. In the Project Manager, click **Import** and pick `spark-swarm/ep04/project.godot`.
3. Press **Play** (F5).

## Controls

| Input | Action |
| --- | --- |
| WASD or arrow keys, gamepad left stick or D-pad | Move |
| Space, gamepad bottom face button | Zap |

## Files

- `spawner.gd`: new. `@export var enemy_scene: PackedScene`, `@export var margin := 64.0`, the `FLOOR` constant, `_on_spawn_timer_timeout()` and `spawn_point()`.
- `arena.tscn`: the Episode 3 arena (five crab instances) plus Spawner › SpawnTimer, with `timeout` connected to `_on_spawn_timer_timeout`.
- `enemy.gd`, `enemy.tscn`, `spark.gd`, `spark.tscn`: same as Episode 3.
- `pillar.tscn`, `project.godot`, `sfx/`, `art/spark_placeholder.svg`, `art/tiny-dungeon/`: same as Episode 3.

## Make it yours

Try it: set SpawnTimer's Wait Time to 0.2 and predict what happens before you press Play. Then set your own pace. Which SpawnTimer property makes crabs arrive twice as fast, and what do you set it to?

## Run it in a browser

The video's last step exports to the web. Export presets aren't included (they're per machine).
In Godot: **Editor › Manage Export Templates** to install the templates, then **Project › Export › Add... › Web**,
and use **Remote Deploy › Run in Browser**.

## How this was made (AI use)

Lexi Volt's narration voice is AI-generated, and the scripts, the music and the project code were written with AI tools.
The spawner was then built in the real Godot 4.8 beta 1 editor UI, step by step as in the video, and run and tested before release.

## Credits & licenses

- Code and scenes: Lexi Volt, MIT (see [LICENSE](LICENSE)).
- Tiles `art/tiny-dungeon/*.png`: **Tiny Dungeon** by Kenney (www.kenney.nl), CC0 1.0. Original `License.txt` in `art/tiny-dungeon/`. Source: https://kenney.nl/assets/tiny-dungeon
- Zap sound `sfx/laserSmall_000.ogg`: **Sci-Fi Sounds** by Kenney (www.kenney.nl), CC0 1.0. Original `License.txt` in `sfx/`.
- Spark picture `art/spark_placeholder.svg`: a simple two-circle shape made for this project, MIT like the code.

## Not included

The headless test and the recording tools used to capture the video aren't included. No music is included. Export presets aren't included (they're per machine); see Episode 1's README to run it in a browser.
