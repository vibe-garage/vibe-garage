# Spark Swarm, Episode 7: Game Over (Godot 4.8 beta 1)

From the Lexi Volt beginner series Spark Swarm, Episode 7, aired **Wed Nov 25, 2026**. [Watch on YouTube](https://www.youtube.com/watch?v=py6PLAkQPUk) · [Full series playlist](https://www.youtube.com/playlist?list=PLSZThGGbiCo0)

Tutorial page with the episode's code and notes: https://vibegarage.neozonesproductions.com/spark-swarm/ep07.html

## What it builds

The end state of Episode 7, starting from Episode 6: at zero health the run ends — a game over screen reads the wave you reached, and R restarts with a clean scene reload.

- `game_over.gd`: a CanvasLayer (Process Mode: Always) that hears the spark's `died`, fills in "You reached wave N", shows the panel and pauses the tree. Restart unpauses first, then `reload_current_scene()`.
- `spark.gd`: Episodes 1–6, plus the `died` signal and the `is_dead` flag so death fires exactly once.
- `wave_spawner.gd` / `wave_banner.gd` / `crab.gd`: the Episode 5–6 systems, unchanged. The spawner is in group `spawner`, which is how the game over screen reads the wave.
- `arena.tscn`: the arena with the GameOver layer in the tree. Project Settings gain a `restart` input action on R.

## Godot version

Made and tested on **Godot 4.8 beta 1** (4.8.beta1.official.4d10419ca), Compatibility renderer, GDScript.

## How to run

1. Open Godot 4.8 beta 1.
2. In the Project Manager, click **Import** and pick `spark-swarm-ep07/project.godot`.
3. Press **Play** (F5).

## Controls

| Input | Action |
| --- | --- |
| WASD or arrow keys, gamepad left stick or D-pad | Move |
| Space, gamepad bottom face button | Zap |
| R | Restart after game over |

## Make it yours

Set First Wave Size to 6 and Wave Growth to 3: how many crabs across waves one to three? (27: six, plus nine, plus twelve.) Then chase your own best wave.

## How this was made (AI use)

Lexi Volt's narration voice is AI-generated, and the scripts and the project code were written with AI tools.
Every project is then built, run and tested in the real Godot 4.8 beta 1 editor before release.

## Credits & licenses

- Code and scenes: Lexi Volt, MIT (see [LICENSE](LICENSE)).
- Sprite art (`art/crab.png`, `art/spark.png`): simple placeholder sprites made for this series, MIT like the code.

## Not included

The headless tests and the recording tools used to capture the video aren't included. No music is included. Export presets aren't included (they're per machine).
