extends CharacterBody2D

@export var speed := 300.0
@export var accel := 3000.0
@export var zap_length := 220.0

const ZAP_COOLDOWN := 0.2
const FLASH_GAP := 0.34

var facing := Vector2.RIGHT
var cooldown := 0.0
var bolt_time := 0.0
var flash_wait := 0.0
var shake_tween: Tween

@onready var zap_line: Line2D = $ZapLine
@onready var zap_sound: AudioStreamPlayer = $ZapSound
@onready var flash_rect: ColorRect = $FlashLayer/Flash


func _physics_process(delta: float) -> void:
	var direction := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	velocity = velocity.move_toward(direction * speed, accel * delta)
	move_and_slide()

	if direction != Vector2.ZERO:
		facing = direction.normalized()
	cooldown -= delta
	bolt_time -= delta
	flash_wait -= delta
	zap_line.visible = bolt_time > 0.0
	if Input.is_action_just_pressed("zap") and cooldown <= 0.0:
		zap()


func zap() -> void:
	cooldown = ZAP_COOLDOWN
	bolt_time = 0.08
	var bolt := PackedVector2Array([Vector2.ZERO])
	for i in range(1, 5):
		var jitter := facing.orthogonal() * randf_range(-14.0, 14.0)
		bolt.append(facing * zap_length * i / 5.0 + jitter)
	bolt.append(facing * zap_length)
	zap_line.points = bolt
	zap_line.show()
	zap_sound.pitch_scale = randf_range(0.95, 1.05)
	zap_sound.play()
	flash()
	shake()


func flash() -> void:
	if flash_wait > 0.0:
		return
	flash_wait = FLASH_GAP
	flash_rect.modulate.a = 0.25
	var tween := create_tween()
	tween.tween_property(flash_rect, "modulate:a", 0.0, 0.1)


func shake() -> void:
	var camera := get_viewport().get_camera_2d()
	if camera == null:
		return
	if shake_tween:
		shake_tween.kill()
	shake_tween = create_tween()
	for i in 4:
		var kick := Vector2(randf_range(-6.0, 6.0), randf_range(-6.0, 6.0))
		shake_tween.tween_property(camera, "offset", kick, 0.03)
	shake_tween.tween_property(camera, "offset", Vector2.ZERO, 0.03)
