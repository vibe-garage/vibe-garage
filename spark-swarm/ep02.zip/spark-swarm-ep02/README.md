# Spark Swarm, Episode 2: Building the Arena (Godot 4.8 beta 1)

From the Lexi Volt beginner series Spark Swarm, Episode 2, airing **Fri Nov 13, 2026**. Video coming soon · [Full series playlist](https://www.youtube.com/playlist?list=PLSZThGGbiCo0)

Project folder: https://github.com/LexiVoltDev/godot-tutorials/tree/main/spark-swarm/ep02
This exact version is tagged `spark-swarm-ep02`: https://github.com/LexiVoltDev/godot-tutorials/tree/spark-swarm-ep02/spark-swarm/ep02

## What it builds

The end state of Episode 2, starting from [Episode 1](https://github.com/LexiVoltDev/godot-tutorials/tree/main/spark-swarm/ep01): the spark now explores a tiled arena two windows wide and two windows tall.

- A `TileMapLayer` floor painted with Kenney Tiny Dungeon tiles (36 x 20 tiles, 64 px each on screen), kept crisp with Texture Filter: Nearest.
- A ring of brick walls with a physics layer, plus three `StaticBody2D` pillars from `pillar.tscn`.
- The camera rides on the spark with position smoothing (speed 5) and stops at the arena's edges (limits 0, 0, 2304, 1280).
- Episode 1's invisible floor fence is gone from `spark.gd`, so the brick walls stop the spark.
- Pillar2 sits one tile from the right wall (2144, 864), the spot found by dragging it live in the Game view and then typing it in. The spark just fits through the gap.

## Godot version

Made and tested on **Godot 4.8 beta 1** (4.8.beta1.official.4d10419ca), Compatibility renderer, GDScript.
Dragging nodes in the Game view while the game runs is new in 4.8, so that part of the UI can still change between betas.

## How to run

1. Open Godot 4.8 beta 1.
2. In the Project Manager, click **Import** and pick `spark-swarm/ep02/project.godot`.
3. Press **Play** (F5).

## Controls

| Input | Action |
| --- | --- |
| WASD or arrow keys, gamepad left stick or D-pad | Move |
| Space, gamepad bottom face button | Zap |

## Try the live editing

1. Press F5. The game runs in the editor's **Game** tab.
2. In the Game view toolbar, click **2D**.
3. In the Scene dock, open the **Remote** tab and click a pillar (a plain click in the game picks the full-screen Flash instead; Alt+right-click also gives a pick list).
4. Use **Move Mode** to drag it. Ctrl+Z (Cmd+Z on a Mac) undoes each drag.
5. Click **Input** and steer again.

Live edits vanish when you stop the game. To keep a spot, note the pillar's Position in the Remote Inspector, stop the game, type the same numbers into the pillar in `arena.tscn`, and save.

## Files

- `arena.tscn`: the main scene. Arena (Texture Filter: Nearest) › Tiles (TileMapLayer, scale 4), Spark, Camera2D (child of Spark), Pillar, Pillar2, Pillar3.
- `pillar.tscn`: Pillar (StaticBody2D) › Sprite2D (brick tile, scale 4) and CollisionShape2D (64 x 64).
- `spark.gd`: Episode 1's code with the floor fence removed. Nothing else changed.
- `spark.tscn`, `project.godot`, `sfx/`, `art/spark_placeholder.svg`: same as Episode 1.
- `art/tiny-dungeon/`: `tilemap_packed.png` (the tile sheet) and `tile_0040.png` (the pillar brick).

## Make it yours

Lay out your own pillars, then try this: if the arena were twice as wide, what would the camera's Right limit be?

## How this was made (AI use)

Lexi Volt's narration voice is AI-generated, and AI tools helped write the episode script and the code in this folder.
The arena was then built in the real Godot 4.8 beta 1 editor UI, step by step as in the video, and run and tested before release.

## Credits & licenses

- Code and scenes: Lexi Volt, MIT (see the repo [LICENSE](LICENSE)).
- Tiles `art/tiny-dungeon/*.png`: **Tiny Dungeon** by Kenney (www.kenney.nl), CC0 1.0. Original `License.txt` in `art/tiny-dungeon/`. Source: https://kenney.nl/assets/tiny-dungeon
- Zap sound `sfx/laserSmall_000.ogg`: **Sci-Fi Sounds** by Kenney (www.kenney.nl), CC0 1.0. Original `License.txt` in `sfx/`.
- Spark picture `art/spark_placeholder.svg`: a simple two-circle shape made for this project, MIT like the code.

## Not included

The headless test and the recording tools used to capture the video aren't included. No music is included. Export presets aren't included (they're per machine); see Episode 1's README to run it in a browser.
