extends CharacterBody2D

@export var speed := 120.0

var target: Node2D


func _physics_process(_delta: float) -> void:
	if target == null:
		return
	velocity = global_position.direction_to(target.global_position) * speed
	move_and_slide()


func _on_sense_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		target = body
