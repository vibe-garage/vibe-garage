# Spark Swarm, Episode 3: First Kill (Godot 4.8 beta 1)

From the Lexi Volt beginner series Spark Swarm, Episode 3, airing **Tue Nov 17, 2026**. Video coming soon · [Full series playlist](https://www.youtube.com/playlist?list=PLSZThGGbiCo0)

Project folder: https://github.com/LexiVoltDev/godot-tutorials/tree/main/spark-swarm/ep03
This exact version is tagged `spark-swarm-ep03`: https://github.com/LexiVoltDev/godot-tutorials/tree/spark-swarm-ep03/spark-swarm/ep03

## What it builds

The end state of Episode 3, starting from [Episode 2](https://github.com/LexiVoltDev/godot-tutorials/tree/main/spark-swarm/ep02): crabs sense the spark, chase it, and die to an auto-aimed zap.

- An `enemy.tscn` crab (`CharacterBody2D` in group `enemies`) with the Kenney Tiny Dungeon red crab, a 24 px body, and a Sense `Area2D` whose radius is 192 px (3 tiles).
- `enemy.gd`: `@export speed := 120.0`, walk at the target with `direction_to`, and `_on_sense_body_entered` only accepts `body.is_in_group("player")`.
- The spark is in group `player`. `spark.gd` adds `nearest_enemy()` and an aimed `zap()` that `queue_free`s the hit. `zap_length` stays 220.
- Five crab instances in `arena.tscn` at (300, 580), (1650, 864), (1500, 200), (1900, 420) and (2000, 520).

## Godot version

Made and tested on **Godot 4.8 beta 1** (4.8.beta1.official.4d10419ca), Compatibility renderer, GDScript.
The Groups and Signals docks in 4.8 can still change between betas.

## How to run

1. Open Godot 4.8 beta 1.
2. In the Project Manager, click **Import** and pick `spark-swarm/ep03/project.godot`.
3. Press **Play** (F5).

## Controls

| Input | Action |
| --- | --- |
| WASD or arrow keys, gamepad left stick or D-pad | Move |
| Space, gamepad bottom face button | Zap |

## Files

- `enemy.gd`: the crab chases its target; Sense only accepts a body in group `player`.
- `enemy.tscn`: Enemy (CharacterBody2D, group `enemies`) › Sprite2D (crab tile, scale 4), CollisionShape2D (circle, radius 24), Sense (Area2D) › CollisionShape2D (circle, radius 192). `body_entered` is connected to `_on_sense_body_entered`.
- `spark.gd`: Episode 2's movement, zap, flash and shake, plus `nearest_enemy()` and an aimed `zap()` that frees the hit. `zap_length` is still 220.
- `spark.tscn`: same Spark scene as Episode 2, with the root now in group `player`.
- `arena.tscn`: the Episode 2 arena plus five `enemy.tscn` instances at (300, 580), (1650, 864), (1500, 200), (1900, 420) and (2000, 520).
- `pillar.tscn`, `project.godot`, `sfx/`, `art/spark_placeholder.svg`, `art/tiny-dungeon/`: same as Episode 2, plus `tile_0110.png` (the crab).

## Make it yours

Place your own crabs and hunt them. Then try this: give a crab a sense radius of four tiles. Does it still wake inside the zap's reach?

## Run it in a browser

The video's last step exports to the web. Export presets aren't included (they're per machine).
In Godot: **Editor › Manage Export Templates** to install the templates, then **Project › Export › Add... › Web**,
and use **Remote Deploy › Run in Browser**.

## How this was made (AI use)

Lexi Volt's narration voice is AI-generated, and the scripts, the music and the project code were written with AI tools.
The enemies and the auto-aimed zap were then built in the real Godot 4.8 beta 1 editor UI, step by step as in the video, and run and tested before release.

## Credits & licenses

- Code and scenes: Lexi Volt, MIT (see [LICENSE](LICENSE)).
- Tiles `art/tiny-dungeon/*.png`: **Tiny Dungeon** by Kenney (www.kenney.nl), CC0 1.0. Original `License.txt` in `art/tiny-dungeon/`. Source: https://kenney.nl/assets/tiny-dungeon
- Zap sound `sfx/laserSmall_000.ogg`: **Sci-Fi Sounds** by Kenney (www.kenney.nl), CC0 1.0. Original `License.txt` in `sfx/`.
- Spark picture `art/spark_placeholder.svg`: a simple two-circle shape made for this project, MIT like the code.

## Not included

The headless test and the recording tools used to capture the video aren't included. No music is included. Export presets aren't included (they're per machine); see Episode 1's README to run it in a browser.
