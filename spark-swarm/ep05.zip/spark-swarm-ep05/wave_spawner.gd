extends Node2D
## WaveSpawner — Spark Swarm Episode 5 ("Waves").
##
## Replaces Episode 4's free-running SpawnTimer: instead of one crab every
## second forever, crabs now arrive in waves. Each wave has a set count,
## a short break follows, and the next wave is bigger.
##
## Scene setup (built in the episode):
##   WaveSpawner (Node2D, this script)
##   ├── SpawnTimer (Timer, one_shot = true)  -> timeout -> _on_spawn_timer_timeout
##   └── BreakTimer (Timer, one_shot = true)  -> timeout -> _on_break_timer_timeout
## The crab scene and the arena are exported vars, set in the Inspector.

signal wave_started(wave_number: int, crab_count: int)
signal wave_cleared(wave_number: int)

## The crab scene, copied once per spawn (Episode 3/4).
@export var crab_scene: PackedScene
## The arena node new crabs are added to, so they live in the world,
## not inside the spawner. (NodePath export: node exports assigned in
## a .tscn need the NodePath form to resolve.)
@export var arena: NodePath

## Crabs in wave 1.
@export var first_wave_size: int = 4
## Extra crabs each new wave adds.
@export var wave_growth: int = 2
## Seconds between crabs inside one wave.
@export var spawn_gap: float = 0.9
## Seconds of quiet between waves.
@export var break_length: float = 4.0

var wave_number: int = 0
var _to_spawn: int = 0  # crabs still owed by the current wave

@onready var _spawn_timer: Timer = $SpawnTimer
@onready var _break_timer: Timer = $BreakTimer


func _ready() -> void:
	# The first wave gets the same short break, so the player sees the
	# arena and the WAVE 1 banner before the first crab walks in.
	_break_timer.start(break_length)


## How many crabs a wave sends. Wave 1: 4, wave 2: 6, wave 3: 8.
func crabs_in_wave(wave: int) -> int:
	return first_wave_size + (wave - 1) * wave_growth


## Seconds one wave's spawning takes: the first crab is instant,
## every crab after it waits one gap. Wave 1: 3 x 0.9 = 2.7 s.
func spawn_span(wave: int) -> float:
	return (crabs_in_wave(wave) - 1) * spawn_gap


func _on_break_timer_timeout() -> void:
	_start_wave()


func _start_wave() -> void:
	wave_number += 1
	_to_spawn = crabs_in_wave(wave_number)
	wave_started.emit(wave_number, _to_spawn)
	_spawn_crab()  # the first crab of the wave arrives right away
	if _to_spawn > 0:
		_spawn_timer.start(spawn_gap)


func _on_spawn_timer_timeout() -> void:
	_spawn_crab()
	if _to_spawn > 0:
		_spawn_timer.start(spawn_gap)


func _spawn_crab() -> void:
	var crab: Node2D = crab_scene.instantiate()
	crab.position = _spawn_point()
	get_node(arena).add_child(crab)
	# tree_exited fires when the crab leaves the tree (it died),
	# which is the spawner's cue to check whether the wave is over.
	crab.tree_exited.connect(_on_crab_gone)
	_to_spawn -= 1


func _on_crab_gone() -> void:
	# A wave is cleared when nothing is left to spawn AND no crab
	# from the group is still alive in the arena.
	if _to_spawn == 0 and get_tree().get_nodes_in_group("enemies").is_empty():
		wave_cleared.emit(wave_number)
		_break_timer.start(break_length)


## A point just outside a random edge of the arena (Episode 4's rule:
## crabs walk in from off screen, from any edge).
func _spawn_point() -> Vector2:
	var rect := Rect2(Vector2(64, 64), Vector2(1024, 520))
	var margin := 48.0
	var edge := randi() % 4
	match edge:
		0:  # top
			return Vector2(randf_range(rect.position.x, rect.end.x), rect.position.y - margin)
		1:  # bottom
			return Vector2(randf_range(rect.position.x, rect.end.x), rect.end.y + margin)
		2:  # left
			return Vector2(rect.position.x - margin, randf_range(rect.position.y, rect.end.y))
		_:  # right
			return Vector2(rect.end.x + margin, randf_range(rect.position.y, rect.end.y))
