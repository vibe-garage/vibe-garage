# Spark Swarm, Episode 5: Waves (Godot 4.8 beta 1)

From the Lexi Volt beginner series Spark Swarm, Episode 5, aired **Mon Nov 23, 2026**. [Watch on YouTube](https://www.youtube.com/watch?v=BcusiNoGYpU) · [Full series playlist](https://www.youtube.com/playlist?list=PLSZThGGbiCo0)

Tutorial page with the episode's code and notes: https://vibegarage.neozonesproductions.com/spark-swarm/ep05.html

## What it builds

The end state of Episode 5, starting from Episode 4: the endless crab flood becomes waves — a count per wave, a gap between crabs, a real break, and a banner that calls each wave.

- `wave_spawner.gd`: the wave spawner. One-shot SpawnTimer pours one wave (First Wave Size 4, Wave Growth 2, Spawn Gap 0.9 s); a one-shot BreakTimer owns the 4 s quiet between waves. `crabs_in_wave(w) = 4 + (w - 1) * 2`. Signals `wave_started` / `wave_cleared`; the cleared check asks the `enemies` group instead of trusting the crab that left.
- `wave_banner.gd`: a Label on a CanvasLayer that hears the spawner's signals, shows WAVE N / CLEARED, and fades over 2 s.
- `crab.gd` / `crab.tscn`: Episode 3's chasing crab, unchanged.
- `spark.gd` / `spark.tscn`: the spark from Episodes 1–3, unchanged.
- `arena.tscn`: the arena with the WaveSpawner (SpawnTimer + BreakTimer) and the banner layer.

## Godot version

Made and tested on **Godot 4.8 beta 1** (4.8.beta1.official.4d10419ca), Compatibility renderer, GDScript.

## How to run

1. Open Godot 4.8 beta 1.
2. In the Project Manager, click **Import** and pick `spark-swarm-ep05/project.godot`.
3. Press **Play** (F5).

## Controls

| Input | Action |
| --- | --- |
| WASD or arrow keys, gamepad left stick or D-pad | Move |
| Space, gamepad bottom face button | Zap |

## Make it yours

Set First Wave Size to 5 and Wave Growth to 3, and predict wave 3 before you run it. (It is 11: five, plus two waves of three.)

## How this was made (AI use)

Lexi Volt's narration voice is AI-generated, and the scripts and the project code were written with AI tools.
Every project is then built, run and tested in the real Godot 4.8 beta 1 editor before release.

## Credits & licenses

- Code and scenes: Lexi Volt, MIT (see [LICENSE](LICENSE)).
- Sprite art (`art/crab.png`, `art/spark.png`): simple placeholder sprites made for this series, MIT like the code.

## Not included

The headless tests and the recording tools used to capture the video aren't included. No music is included. Export presets aren't included (they're per machine).
