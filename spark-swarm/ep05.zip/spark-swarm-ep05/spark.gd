extends CharacterBody2D
## Spark — the player (Episodes 1 + 3, series build).
## Eased movement (Ep1), fence clamp to the floor (Ep1), auto-aim zap
## that damages the nearest crab in range (Ep3). Zap feel: a line,
## a flash, a shake (Ep1). `autoplay` drives the spark for captures.

@export var speed: float = 300.0
@export var accel: float = 3000.0
@export var zap_range: float = 230.0
@export var zap_cooldown: float = 0.35
@export var autoplay: bool = false

const FLOOR_MIN := Vector2(64, 64)
const FLOOR_MAX := Vector2(1088, 584)
const RADIUS := 20.0

var _cooldown_left: float = 0.0
var _facing: Vector2 = Vector2.RIGHT

@onready var _zap_line: Line2D = $ZapLine
@onready var _flash: ColorRect = $FlashLayer/Flash


func _physics_process(delta: float) -> void:
	var input_dir := Vector2.ZERO
	if autoplay:
		input_dir = _autoplay_dir()
	else:
		input_dir = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	var target := input_dir * speed
	velocity = velocity.move_toward(target, accel * delta)
	move_and_slide()
	global_position.x = clampf(global_position.x, FLOOR_MIN.x + RADIUS, FLOOR_MAX.x - RADIUS)
	global_position.y = clampf(global_position.y, FLOOR_MIN.y + RADIUS, FLOOR_MAX.y - RADIUS)
	if input_dir != Vector2.ZERO:
		_facing = input_dir.normalized()
	_cooldown_left -= delta
	if _cooldown_left <= 0.0:
		var crab := _nearest_crab()
		if crab != null:
			_zap(crab)


func _nearest_crab() -> Node2D:
	var best: Node2D = null
	var best_d := zap_range
	for node in get_tree().get_nodes_in_group("enemies"):
		var d := global_position.distance_to(node.global_position)
		if d < best_d:
			best_d = d
			best = node
	return best


func _autoplay_dir() -> Vector2:
	# Kite the nearest crab: hold about 150 px from it, strafing slowly,
	# so the zap stays in range and the picture keeps moving.
	var crab := _nearest_crab_any()
	if crab == null:
		return Vector2.ZERO
	var to_crab := crab.global_position - global_position
	var dist := to_crab.length()
	var radial := 0.0
	if dist > 170.0:
		radial = 1.0
	elif dist < 120.0:
		radial = -1.0
	var tangent := to_crab.normalized().orthogonal() * 0.6
	return (to_crab.normalized() * radial + tangent).normalized()


func _nearest_crab_any() -> Node2D:
	var best: Node2D = null
	var best_d := INF
	for node in get_tree().get_nodes_in_group("enemies"):
		var d := global_position.distance_to(node.global_position)
		if d < best_d:
			best_d = d
			best = node
	return best


func _zap(crab: Node2D) -> void:
	_cooldown_left = zap_cooldown
	_facing = (crab.global_position - global_position).normalized()
	# The line: a jagged bolt to the crab (Ep1).
	var pts: PackedVector2Array = [Vector2.ZERO]
	var dir := _facing
	var side := dir.orthogonal()
	var dist := global_position.distance_to(crab.global_position)
	for i in range(1, 4):
		var along := dist * i / 4.0
		pts.append(dir * along + side * randf_range(-13.0, 13.0))
	pts.append(dir * dist)
	_zap_line.points = pts
	_zap_line.visible = true
	# The flash (Ep1): alpha 0.25, gone in a tenth of a second.
	_flash.modulate.a = 0.25
	var tw := create_tween()
	tw.tween_property(_flash, "modulate:a", 0.0, 0.1)
	tw.parallel().tween_callback(func() -> void: _zap_line.visible = false).set_delay(0.08)
	# The hit (Ep3): one zap, one crab down.
	if crab.has_method("take_hit"):
		crab.take_hit()
