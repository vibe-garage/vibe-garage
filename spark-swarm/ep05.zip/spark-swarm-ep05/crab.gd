extends CharacterBody2D
## Crab — the enemy (Episode 3, series build).
## Walks at the spark and dies to one zap. Lives in the "enemies"
## group (set in the scene, the Groups-dock way, so it persists).

@export var speed: float = 95.0

var _target: Node2D


func _ready() -> void:
	_target = get_tree().get_first_node_in_group("player") as Node2D


func _physics_process(_delta: float) -> void:
	if _target == null:
		return
	var dir := (_target.global_position - global_position).normalized()
	velocity = dir * speed
	move_and_slide()


func take_hit() -> void:
	# One zap is enough (Ep3). Leaving the tree fires tree_exited,
	# which is how the Ep5 spawner knows a crab is gone.
	queue_free()
