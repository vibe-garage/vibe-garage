extends Area2D
## Gem — Spark Swarm Episode 9 ("Loot Drop").
## (Ep9's gem, with one Ep11 change, included in Ep11's package so
## its smoke test runs standalone. The gem is Ep11's XP source via
## the spawner's collected hookup. The Ep11 change: the pull radius
## is read from the spark's magnet_radius setting each frame, so
## the Gem Magnet power-up can double it; this gem's own export
## stays as the fallback for a spark without the setting.)
##
## The pickup a zapped crab can drop. Gem art is a Kenney asset (CC0);
## see the episode CREDITS — the credit is a hard requirement.
##
## Scene setup (built in the episode):
##   Gem (Area2D, this script)
##   ├── Sprite2D (the Kenney gem texture)
##   └── CollisionShape2D (CircleShape2D, radius 14 — about as wide
##       as the gem looks; that circle is the pickup's reach)
## The spark is a CharacterBody2D in the "player" group, so the
## area's body_entered signal is the touch. Inside the magnet radius
## the gem drifts to the spark on its own, so collecting never
## feels like sweeping.

signal collected(gem: Area2D)

## How close (px) the spark has to be before the gem starts drifting.
@export var magnet_radius: float = 90.0
## How fast (px/s) the gem drifts once the spark is close.
## Crabs walk at 95, so 260 always wins the race.
@export var magnet_speed: float = 260.0

var _collected: bool = false


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _physics_process(_delta: float) -> void:
	var spark := get_tree().get_first_node_in_group("player") as Node2D
	if spark == null:
		return
	# Ep11: the reach lives on the spark, so a power-up can move
	# it. A spark with no magnet_radius setting (an older build)
	# falls back to this gem's own export — Ep9's behaviour.
	var reach := magnet_radius
	var spark_reach = spark.get("magnet_radius")
	if spark_reach != null:
		reach = float(spark_reach)
	var to_spark := spark.global_position - global_position
	if to_spark.length() < reach:
		global_position += to_spark.normalized() * magnet_speed * _delta


func _on_body_entered(body: Node2D) -> void:
	# Only the spark collects. A crab wandering through its own
	# dropped gem, or a wall, is ignored.
	if _collected or not body.is_in_group("player"):
		return
	_collected = true
	collected.emit(self)
	queue_free()
