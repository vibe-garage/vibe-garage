extends CanvasLayer
## PowerUpLayer — Spark Swarm Episode 11 ("Power Up").
##
## When the spawner shouts level_up (Ep10), this layer freezes the
## fight and offers three power-ups as cards. The pick is applied
## to the spark's settings, the panel closes, and the tree unpauses.
##
## Scene setup (built in the episode):
##   PowerUpLayer (CanvasLayer, this script)
##     Process Mode: Always (set in the Inspector) — THE EPISODE'S
##     BUG AND FIX. The first build left this at Inherit: the panel
##     showed, the tree paused, and the layer paused with it, so
##     every button was dead and the run soft-locked behind glass.
##     Always means the layer (and its buttons, which inherit from
##     it) keeps working while the world stays frozen — Episode 7's
##     game-over lesson, one episode early and one layer over.
##   └── Panel (Control, full rect, starts hidden)
##       ├── Dim (ColorRect, full rect, black, alpha 0.55)
##       ├── Title (Label, "LEVEL 2 — PICK ONE", set in code)
##       └── Cards (HBoxContainer)
##           ├── Button (text set in code from CHOICES)
##           ├── Button
##           └── Button
##
## The choices are data, not scenes: one dictionary per card, and
## the buttons' text is written from it in _ready, so what a card
## says can never drift from what the pick does.

const CHOICES: Array = [
	{"id": "rapid", "title": "RAPID ZAP", "blurb": "Zap twice as fast"},
	{"id": "wide", "title": "WIDE ZAP", "blurb": "Zap reaches half again as far"},
	{"id": "magnet", "title": "GEM MAGNET", "blurb": "Gems lean in from twice as far"},
]

@onready var _panel: Control = $Panel
@onready var _title: Label = $Panel/Title
@onready var _cards: HBoxContainer = $Panel/Cards

## Levels whose choice is still owed. A level can't land while the
## tree is paused (no XP flows), so this is 1 in real play; the
## queue exists so a multi-level grant can never eat a pick.
var _pending: Array[int] = []


func _ready() -> void:
	_panel.hide()
	# The cards say what the data says.
	var buttons := _cards.get_children()
	for i in buttons.size():
		var button := buttons[i] as Button
		var choice: Dictionary = CHOICES[i]
		button.text = "%s\n%s" % [choice["title"], choice["blurb"]]
		button.pressed.connect(choose.bind(choice["id"]))
	# The banner found the spawner by its group in Episode 5;
	# the level display did the same in Episode 10.
	var spawner := get_tree().get_first_node_in_group("spawner")
	if spawner != null:
		spawner.level_up.connect(_on_level_up)


func _on_level_up(new_level: int) -> void:
	_pending.append(new_level)
	if _panel.visible:
		return  # a choice is already open; this one queues behind it
	_open_choice()


func _open_choice() -> void:
	_title.text = "LEVEL %d — PICK ONE" % _pending[0]
	_panel.show()
	# Freeze the fight. The layer itself stays awake (Process Mode:
	# Always) so the buttons can be clicked; nothing else moves.
	get_tree().paused = true


## One function for all three picks: the ID says which, the
## function does the rest. Connected to every card's pressed
## signal in _ready, with the ID bound in.
func choose(choice_id: String) -> void:
	_apply_power_up(choice_id)
	_pending.pop_front()
	if not _pending.is_empty():
		_open_choice()  # another level is owed its pick; stay frozen
		return
	_panel.hide()
	get_tree().paused = false


## The whole power-up system: three settings on the spark, reached
## through the player group (Episode 3's targeting group). Picks
## stack — the same card picked at a later level applies again.
func _apply_power_up(choice_id: String) -> void:
	var spark := get_tree().get_first_node_in_group("player")
	if spark == null:
		return
	match choice_id:
		"rapid":
			# 0.20 -> 0.10 -> 0.05 ... five zaps a second -> ten.
			spark.zap_cooldown *= 0.5
		"wide":
			# 230 -> 345 -> ... half again as far, every pick.
			spark.zap_range *= 1.5
		"magnet":
			# 90 -> 180 -> 360 ... the gems' pull reaches twice as
			# far, every pick. (No zap setting is ever touched: one
			# zap stays one hit, the rule Ep12's boss relies on.)
			spark.magnet_radius *= 2.0
