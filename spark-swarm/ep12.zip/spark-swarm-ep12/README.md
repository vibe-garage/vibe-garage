# Spark Swarm, Episode 9: Loot Drop (Godot 4.8 beta 1)

From the Lexi Volt beginner series Spark Swarm, Episode 9, aired
**Fri Nov 27, 2026**. [Watch on YouTube](https://www.youtube.com/watch?v=VIDEO_ID_PENDING)

The finished project from "Godot 4.8 for Beginners: Make Every Kill
Drop Loot" (Lexi Volt, @LexiVoltDev).

Zapped crabs drop a gem one time in four. Walk into a gem to collect
it: the magnet pulls it in from 90 pixels, and every gem is worth 10
points on the score label the spawner drives.

## Run it

Open the folder in Godot 4.8 beta 1 and press Play. WASD or arrow
keys move the spark; it zaps on its own. Survive the waves.

## Files

- `gem.gd` / `gem.tscn` — the pickup: an Area2D with a `collected`
  signal and the magnet glide.
- `crab.gd` — gains the `died` signal, emitted only from `take_hit`.
- `wave_spawner.gd` — the drop roll, the score, `score_changed`.
- `score_label.gd` — the HUD score readout.
- `art/` — the sprites (see CREDITS.md).

## License

Code is MIT (see LICENSE). Art is by Kenney, CC0 (see CREDITS.md).
