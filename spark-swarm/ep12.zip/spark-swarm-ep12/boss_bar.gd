extends ProgressBar
## BossBar — Spark Swarm Episode 12 ("The Boss").
##
## The boss's health, drawn as a bar across the top of the Ep8 HUD.
## The bar owns no numbers: the spawner relays the boss's shouts
## (boss_started, boss_health_changed, boss_defeated), and this
## script's whole job is: hear the shout, set the bar. Same pattern
## as Ep9's score label, wearing a bigger hat.
##
## Scene setup: a ProgressBar in the HUD's CanvasLayer, stretched
## across the top (the episode sets Show Percentage off and puts a
## "BOSS" label beside it). The spawner is found through the
## "spawner" group — the same lookup the Ep5 WaveBanner and Ep9's
## score label use. Hidden until the boss walks in.

func _ready() -> void:
	visible = false
	var spawner := get_tree().get_first_node_in_group("spawner")
	if spawner != null:
		spawner.boss_started.connect(_on_boss_started)
		spawner.boss_health_changed.connect(_on_boss_health_changed)
		spawner.boss_defeated.connect(_on_boss_defeated)


func _on_boss_started(boss_max_health: int) -> void:
	max_value = boss_max_health
	value = boss_max_health
	visible = true


func _on_boss_health_changed(current: int, _maximum: int) -> void:
	value = current


func _on_boss_defeated() -> void:
	visible = false
