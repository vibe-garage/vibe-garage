extends "res://crab.gd"
## Boss — Spark Swarm Episode 12 ("The Boss").
##
## A MINIMAL boss, on purpose: the full fight is Episode 23's job
## (Season 2). This one is the series crab, promoted — the boss
## scene is an INHERITED SCENE of the crab scene (same walk, same
## touch, same knockback, same zap rules), and this script EXTENDS
## the crab's script, so the boss does everything a crab does until
## it says otherwise. What it says otherwise is exactly three
## things:
##   1. It has health: 40 zap hits instead of 1.
##   2. It shouts health_changed, so the HUD can draw a boss bar.
##   3. Every 6 seconds it asks for a minion (minion_requested).
##      It never spawns anything itself — the spawner spawns every
##      enemy in the game, so every death lands in the same books.
##      (Version 1 let the boss spawn its own minions; their exits
##      were connected to nothing, the wave-clear check never ran
##      for the last one, and wave 10 could never end. See the
##      episode's smoke test, which reproduces that soft-lock.)
##
## One deliberate exception to "everything a crab does": the boss
## NEVER shouts the crabs' died signal. died is the regular crabs'
## kill tally — Ep9's loot roll hangs off it, and Ep13 counts
## zapped crabs through it (130 across waves 1–10, a number the
## boss is not part of). A boss kill is announced on the boss's
## OWN signal, defeated, so nothing that tallies crab kills can
## ever count the boss by accident.
##
## Tuning lives in the boss SCENE (the inherited scene's Inspector
## overrides), not in this script:
##   Sprite scale 3, 3 — the series crab art, three times the crab.
##   Speed 60 — slower than a regular crab's 95. The spark runs at
##     300, so the boss was never going to catch anyone; its legs
##     are not the threat. Its health and its company are.
##   Damage 20 — one boss touch costs 20 health, two HUD pips.
##     100 / 20 = 5 boss touches empty the spark, where a regular
##     crab's 10 takes ten touches.
##
## Scene setup (built in the episode):
##   Boss (CharacterBody2D, this script; inherited from Crab.tscn,
##   in the "enemies" group like every crab — the spark's zap finds
##   its targets in that group, so the boss has to be in it)
##   ├── Sprite2D (the crab texture, scale 3, 3)
##   ├── CollisionShape2D (the crab's circle, scaled with the scene)
##   └── MinionTimer (Timer, wait_time 6.0, one_shot = false,
##       autostart = true) -> timeout connected in _ready below

## Shouted on every landed zap: the bar's numbers. Same pattern as
## the spark's health_changed (Ep6) — the owner of the number
## announces it; the HUD only listens.
signal health_changed(current: int, maximum: int)
## The boss's OWN death shout — deliberately NOT the crabs' died
## signal (see the header). The spawner hears this one and relays
## it as boss_defeated for the HUD; the died tally never sees it.
signal defeated(at_position: Vector2)
## Shouted every minion_interval seconds. The spawner hears it and
## spawns a regular crab at the boss, through the same door every
## wave crab uses — same connections, same loot roll, same count.
signal minion_requested

## Zap hits the boss can take. A regular crab takes 1.
## Time-to-kill floor: 40 hits x the spark's 0.2 s zap cooldown
## = 8.0 s of perfect zapping. Real fights run longer: the zap
## takes the NEAREST enemy in range, and minions steal zaps.
@export var max_health: int = 40

var health: int

@onready var _minion_timer: Timer = $MinionTimer


func _ready() -> void:
	super._ready()  # the crab's ready: find the spark
	health = max_health
	_minion_timer.timeout.connect(_on_minion_timer_timeout)


## The crab's take_hit, overridden: a zap costs the boss ONE health,
## not its life. One zap, one health, by construction — no matter
## what any power-up does to regular crabs, the count stays honest.
## Only the hit that reaches zero is a kill, and a boss kill is
## announced on defeated — the boss's own signal, never on the
## crabs' died — before the boss leaves.
func take_hit() -> void:
	if health <= 0:
		return  # already dead; queue_free is on its way
	health -= 1
	health_changed.emit(health, max_health)
	if health <= 0:
		defeated.emit(global_position)
		queue_free()


func _on_minion_timer_timeout() -> void:
	minion_requested.emit()
