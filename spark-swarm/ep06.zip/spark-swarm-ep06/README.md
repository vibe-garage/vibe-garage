# Spark Swarm, Episode 6: Ouch (Godot 4.8 beta 1)

From the Lexi Volt beginner series Spark Swarm, Episode 6, aired **Tue Nov 24, 2026**. [Watch on YouTube](https://www.youtube.com/watch?v=3FO8w9vH4L4) · [Full series playlist](https://www.youtube.com/playlist?list=PLSZThGGbiCo0)

Tutorial page with the episode's code and notes: https://vibegarage.neozonesproductions.com/spark-swarm/ep06.html

## What it builds

The end state of Episode 6, starting from Episode 5: the spark gains health, a crab's touch costs ten of it, and a mercy cooldown keeps one touch to one hit.

- `spark.gd`: Episodes 1–5 movement and zap, plus health (Max Health 100), the `health_changed` signal, `take_damage` with the 0.5 s mercy cooldown, and the red damage flash. No game over yet — health stops at zero (that's Episode 7). No hit sound.
- `crab.gd`: the chase, plus Damage 10, the slide-collision touch check after `move_and_slide`, and a knockback that fires only when a hit actually lands.
- `wave_spawner.gd` / `wave_banner.gd`: Episode 5's wave system, unchanged.
- `arena.tscn`, `spark.tscn`, `crab.tscn`: the scenes, with the spark's health settings in the Inspector.

## Godot version

Made and tested on **Godot 4.8 beta 1** (4.8.beta1.official.4d10419ca), Compatibility renderer, GDScript.

## How to run

1. Open Godot 4.8 beta 1.
2. In the Project Manager, click **Import** and pick `spark-swarm-ep06/project.godot`.
3. Press **Play** (F5).

## Controls

| Input | Action |
| --- | --- |
| WASD or arrow keys, gamepad left stick or D-pad | Move |
| Space, gamepad bottom face button | Zap |

## Make it yours

Set crab damage to 20 and predict the run: how many hits empty a full bar? (Five: 100 / 20.) Then decide what a hit should cost in your game.

## How this was made (AI use)

Lexi Volt's narration voice is AI-generated, and the scripts and the project code were written with AI tools.
Every project is then built, run and tested in the real Godot 4.8 beta 1 editor before release.

## Credits & licenses

- Code and scenes: Lexi Volt, MIT (see [LICENSE](LICENSE)).
- Sprite art (`art/crab.png`, `art/spark.png`): simple placeholder sprites made for this series, MIT like the code.

## Not included

The headless tests and the recording tools used to capture the video aren't included. No music is included. Export presets aren't included (they're per machine).
