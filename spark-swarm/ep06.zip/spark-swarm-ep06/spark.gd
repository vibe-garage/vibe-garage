extends CharacterBody2D
## Spark — the player (Episodes 1 + 3 + 6, series build).
## Eased movement (Ep1), fence clamp to the floor (Ep1), auto-aim zap
## that damages the nearest crab in range (Ep3). Zap feel: a line,
## a flash, a shake (Ep1). `autoplay` drives the spark for captures.
##
## Ep6 adds health: a crab touch costs health, a red flash shows the
## hit, and a half-second mercy cooldown means one touch is one hit.
## There is deliberately NO game over yet — health stops at zero and
## the spark keeps going (that's Episode 7). There is also no hit
## sound: the sound is saved for the juice episode.

signal health_changed(new_health: int)

@export var speed: float = 300.0
@export var accel: float = 3000.0
@export var zap_range: float = 230.0
@export var zap_cooldown: float = 0.2
## Health the spark starts with. Ten clean crab hits empty it.
@export var max_health: int = 100
## Seconds after a landed hit during which the spark can't be hurt
## again. This cooldown belongs to the spark, not to any one crab,
## so a whole swarm shares the same speed limit.
@export var hit_cooldown: float = 0.5
@export var autoplay: bool = false

const FLOOR_MIN := Vector2(64, 64)
const FLOOR_MAX := Vector2(1088, 584)
const RADIUS := 20.0

var health: int

var _cooldown_left: float = 0.0
var _hit_left: float = 0.0
var _facing: Vector2 = Vector2.RIGHT

@onready var _sprite: Sprite2D = $Sprite
@onready var _zap_line: Line2D = $ZapLine
@onready var _flash: ColorRect = $FlashLayer/Flash


func _ready() -> void:
	health = max_health


func _physics_process(delta: float) -> void:
	_hit_left = maxf(_hit_left - delta, 0.0)
	var input_dir := Vector2.ZERO
	if autoplay:
		input_dir = _autoplay_dir()
	else:
		input_dir = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	var target := input_dir * speed
	velocity = velocity.move_toward(target, accel * delta)
	move_and_slide()
	global_position.x = clampf(global_position.x, FLOOR_MIN.x + RADIUS, FLOOR_MAX.x - RADIUS)
	global_position.y = clampf(global_position.y, FLOOR_MIN.y + RADIUS, FLOOR_MAX.y - RADIUS)
	if input_dir != Vector2.ZERO:
		_facing = input_dir.normalized()
	_cooldown_left -= delta
	if _cooldown_left <= 0.0:
		var crab := _nearest_crab()
		if crab != null:
			_zap(crab)


## Something hurt the spark. Returns true when the hit counted, so
## the attacker knows it connected (the crab bounces off only then).
## While the mercy cooldown is still running, the hit is ignored:
## a touch that stays touching does not keep paying out.
func take_damage(amount: int) -> bool:
	if _hit_left > 0.0:
		return false
	_hit_left = hit_cooldown
	health = clampi(health - amount, 0, max_health)
	health_changed.emit(health)
	_flash_damage()
	return true


func _flash_damage() -> void:
	# The damage feedback (Ep6): the sprite blinks red and settles
	# back over a quarter of a second. A tween, like the Ep5 banner.
	# No sound here — the hit sound is saved for the juice episode.
	_sprite.modulate = Color(1.0, 0.3, 0.3)
	var tw := create_tween()
	tw.tween_property(_sprite, "modulate", Color.WHITE, 0.25)


func _nearest_crab() -> Node2D:
	var best: Node2D = null
	var best_d := zap_range
	for node in get_tree().get_nodes_in_group("enemies"):
		var d := global_position.distance_to(node.global_position)
		if d < best_d:
			best_d = d
			best = node
	return best


func _autoplay_dir() -> Vector2:
	# Kite the nearest crab: hold about 150 px from it, strafing slowly,
	# so the zap stays in range and the picture keeps moving.
	var crab := _nearest_crab_any()
	if crab == null:
		return Vector2.ZERO
	var to_crab := crab.global_position - global_position
	var dist := to_crab.length()
	var radial := 0.0
	if dist > 170.0:
		radial = 1.0
	elif dist < 120.0:
		radial = -1.0
	var tangent := to_crab.normalized().orthogonal() * 0.6
	return (to_crab.normalized() * radial + tangent).normalized()


func _nearest_crab_any() -> Node2D:
	var best: Node2D = null
	var best_d := INF
	for node in get_tree().get_nodes_in_group("enemies"):
		var d := global_position.distance_to(node.global_position)
		if d < best_d:
			best_d = d
			best = node
	return best


func _zap(crab: Node2D) -> void:
	_cooldown_left = zap_cooldown
	_facing = (crab.global_position - global_position).normalized()
	# The line: a jagged bolt to the crab (Ep1).
	var pts: PackedVector2Array = [Vector2.ZERO]
	var dir := _facing
	var side := dir.orthogonal()
	var dist := global_position.distance_to(crab.global_position)
	for i in range(1, 4):
		var along := dist * i / 4.0
		pts.append(dir * along + side * randf_range(-13.0, 13.0))
	pts.append(dir * dist)
	_zap_line.points = pts
	_zap_line.visible = true
	# The flash (Ep1): alpha 0.25, gone in a tenth of a second.
	_flash.modulate.a = 0.25
	var tw := create_tween()
	tw.tween_property(_flash, "modulate:a", 0.0, 0.1)
	tw.parallel().tween_callback(func() -> void: _zap_line.visible = false).set_delay(0.08)
	# The hit (Ep3): one zap, one crab down.
	if crab.has_method("take_hit"):
		crab.take_hit()
