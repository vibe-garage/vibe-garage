extends Node2D
## WaveSpawner — Spark Swarm Episodes 5 + 8 + 9.
##
## Replaces Episode 4's free-running SpawnTimer: instead of one crab every
## second forever, crabs now arrive in waves. Each wave has a set count,
## a short break follows, and the next wave is bigger.
##
## Ep9 adds the loot system on top: when a zapped crab dies it shouts
## died (Ep9's crab script), the spawner rolls the drop chance exactly
## once per kill, and a winning roll drops a gem (gem.gd) where the
## crab fell. Collected gems feed the score, which the HUD shows
## through score_changed (Ep8's signal pattern).
##
## Scene setup (built in the episode):
##   WaveSpawner (Node2D, this script)
##   ├── SpawnTimer (Timer, one_shot = true)  -> timeout -> _on_spawn_timer_timeout
##   └── BreakTimer (Timer, one_shot = true)  -> timeout -> _on_break_timer_timeout
## The crab scene, gem scene and arena are exported vars, set in
## the Inspector.

signal wave_started(wave_number: int, crab_count: int)
signal wave_cleared(wave_number: int)
## NEW in Episode 8: the crabs-left count, announced on every change.
signal wave_progress(remaining: int)
## NEW in Episode 9: the score, announced every time it moves;
## the HUD's score label listens.
signal score_changed(new_score: int)

## The crab scene, copied once per spawn (Episode 3/4).
@export var crab_scene: PackedScene
## The gem scene (Ep9), copied once per winning drop roll.
@export var gem_scene: PackedScene
## The arena node new crabs (and dropped gems) are added to, so they
## live in the world, not inside the spawner. (NodePath export: node
## exports assigned in a .tscn need the NodePath form to resolve.)
@export var arena: NodePath

## Crabs in wave 1.
@export var first_wave_size: int = 4
## Extra crabs each new wave adds.
@export var wave_growth: int = 2
## Seconds between crabs inside one wave.
@export var spawn_gap: float = 0.9
## Seconds of quiet between waves.
@export var break_length: float = 4.0
## The odds that one kill drops a gem. 0.25 is one in four.
@export var drop_chance: float = 0.25
## Points one collected gem is worth.
@export var gem_value: int = 10

var wave_number: int = 0
## The run's score. Lives here, so a restart (fresh scene) resets
## it — Ep9's honest limit; saving it is a later episode's job.
var score: int = 0
var _to_spawn: int = 0  # crabs still owed by the current wave

@onready var _spawn_timer: Timer = $SpawnTimer
@onready var _break_timer: Timer = $BreakTimer


func _ready() -> void:
	# The first wave gets the same short break, so the player sees the
	# arena and the WAVE 1 banner before the first crab walks in.
	_break_timer.start(break_length)


## How many crabs a wave sends. Wave 1: 4, wave 2: 6, wave 3: 8.
func crabs_in_wave(wave: int) -> int:
	return first_wave_size + (wave - 1) * wave_growth


## Seconds one wave's spawning takes: the first crab is instant,
## every crab after it waits one gap. Wave 1: 3 x 0.9 = 2.7 s.
func spawn_span(wave: int) -> float:
	return (crabs_in_wave(wave) - 1) * spawn_gap


## On-average gems for a clear of this many crabs: kills times the
## chance. Wave 3: 8 x 0.25 = 2. An average, not a promise.
func expected_gems(crab_count: int) -> float:
	return crab_count * drop_chance


## NEW in Episode 8: crabs the player still has to beat this wave —
## the ones on screen plus the ones this wave still owes. This is
## the HUD's number, and only the spawner can count both halves.
func crabs_remaining() -> int:
	return _to_spawn + get_tree().get_nodes_in_group("enemies").size()


func _on_break_timer_timeout() -> void:
	_start_wave()


func _start_wave() -> void:
	wave_number += 1
	_to_spawn = crabs_in_wave(wave_number)
	wave_started.emit(wave_number, _to_spawn)
	wave_progress.emit(crabs_remaining())  # NEW in Episode 8
	_spawn_crab()  # the first crab of the wave arrives right away
	if _to_spawn > 0:
		_spawn_timer.start(spawn_gap)


func _on_spawn_timer_timeout() -> void:
	_spawn_crab()
	if _to_spawn > 0:
		_spawn_timer.start(spawn_gap)


func _spawn_crab() -> void:
	var crab = crab_scene.instantiate()
	crab.position = _spawn_point()
	get_node(arena).add_child(crab)
	# tree_exited fires when the crab leaves the tree (any reason),
	# which is the spawner's cue to check whether the wave is over.
	crab.tree_exited.connect(_on_crab_gone)
	# died fires only for a zap kill, and carries the spot where the
	# crab fell — that's the drop roll's one hookup. (The crab is
	# deliberately untyped here: died is the crab script's own
	# signal, not a Node2D one.)
	crab.died.connect(_on_crab_died)
	_to_spawn -= 1
	# Owed became alive: the total does not move, but it is still
	# announced, so listeners never have to wonder. (Episode 8.)
	wave_progress.emit(crabs_remaining())


func _on_crab_gone() -> void:
	# During a scene reload (Ep7), a crab can leave the tree after
	# the spawner itself has already left it — get_tree() is null
	# then, and there is no wave left to check. Bail out quietly.
	if not is_inside_tree():
		return
	# The count changed the moment the crab left; say so first.
	wave_progress.emit(crabs_remaining())  # NEW in Episode 8
	# A wave is cleared when nothing is left to spawn AND no crab
	# from the group is still alive in the arena.
	if _to_spawn == 0 and get_tree().get_nodes_in_group("enemies").is_empty():
		wave_cleared.emit(wave_number)
		_break_timer.start(break_length)


## THE DROP ROLL. Runs exactly once per kill, because died does.
## The Ep9 bug was this same roll sitting in a physics process,
## where it ran ~60 times a second per crab (60 x 0.25 = 15 gems
## a second). Random rewards roll at the event, never in a loop.
func _on_crab_died(at_position: Vector2) -> void:
	if randf() < drop_chance:
		_drop_gem(at_position)


func _drop_gem(at_position: Vector2) -> void:
	var gem = gem_scene.instantiate()
	gem.position = at_position
	get_node(arena).add_child(gem)
	gem.collected.connect(_on_gem_collected)


func _on_gem_collected(_gem: Area2D) -> void:
	score += gem_value
	score_changed.emit(score)


## A point just outside a random edge of the arena (Episode 4's rule:
## crabs walk in from off screen, from any edge).
func _spawn_point() -> Vector2:
	var rect := Rect2(Vector2(64, 64), Vector2(1024, 520))
	var margin := 48.0
	var edge := randi() % 4
	match edge:
		0:  # top
			return Vector2(randf_range(rect.position.x, rect.end.x), rect.position.y - margin)
		1:  # bottom
			return Vector2(randf_range(rect.position.x, rect.end.x), rect.end.y + margin)
		2:  # left
			return Vector2(rect.position.x - margin, randf_range(rect.position.y, rect.end.y))
		_:  # right
			return Vector2(rect.end.x + margin, randf_range(rect.position.y, rect.end.y))
