# Spark Swarm — Episode 9 project credits

Art — all from **"Platformer Pack Remastered" by Kenney** (kenney.nl),
Creative Commons CC0:
- Gem: `art/gem.png` (the pack's gemBlue.png). Credit kept by series
  rule (Ep9 hard requirement).
- Crab: `art/ladybug.png` (the pack's ladybug — the packs contain no
  crab; the ladybug plays the crab, logged as a substitution).
- Spark: `art/star.png` (the pack's star).
- Backdrop: `art/backdrop.png` (the pack's blue_land, darkened).

Sound (in the video mix, not in this project): Kenney CC0 packs —
Digital Audio, Sci-Fi Sounds, Interface Sounds.

Everything else: built in Godot 4.8 beta 1 with GDScript written for
the Spark Swarm series.
